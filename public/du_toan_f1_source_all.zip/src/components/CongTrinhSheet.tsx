import React, { useState, useMemo } from 'react';
import { WorkItem, Category, SubCalculation } from '../types/estimate';
import { evaluateMathExpression, formatQuantity, formatVND } from '../utils/calculator';
import { 
  checkTextSpelling, autoCorrectText, applySpellCorrection, 
  SpellCheckIssue, CONSTRUCTION_STANDARD_LEXICON 
} from '../utils/constructionSpellChecker';
import { 
  Plus, Trash2, ChevronDown, ChevronRight, Edit3, Search, 
  Sparkles, CheckCircle2, AlertCircle, Wand2, X, RefreshCw, BookOpen, Check
} from 'lucide-react';

interface CongTrinhSheetProps {
  items: WorkItem[];
  categories: Category[];
  selectedItemId: string | null;
  selectedSubCalcId: string | null;
  onSelectItem: (item: WorkItem, subCalc?: SubCalculation) => void;
  onUpdateWorkItem: (itemId: string, patch: Partial<WorkItem>) => void;
  onDeleteWorkItem: (itemId: string) => void;
  onAddSubCalculation: (itemId: string) => void;
  onUpdateSubCalculation: (itemId: string, subId: string, patch: Partial<SubCalculation>) => void;
  onDeleteSubCalculation: (itemId: string, subId: string) => void;
  onOpenNormLookupForWorkItem: (itemId: string) => void;
  onAddCategory: () => void;
}

export const CongTrinhSheet: React.FC<CongTrinhSheetProps> = ({
  items,
  categories,
  selectedItemId,
  selectedSubCalcId,
  onSelectItem,
  onUpdateWorkItem,
  onDeleteWorkItem,
  onAddSubCalculation,
  onUpdateSubCalculation,
  onDeleteSubCalculation,
  onOpenNormLookupForWorkItem,
}) => {
  const [collapsedCategories, setCollapsedCategories] = useState<Record<string, boolean>>({});
  const [isSpellCheckEnabled, setIsSpellCheckEnabled] = useState<boolean>(true);
  const [showSpellCheckDrawer, setShowSpellCheckDrawer] = useState<boolean>(false);
  const [activeSuggestionPopover, setActiveSuggestionPopover] = useState<string | null>(null);

  const toggleCategory = (catId: string) => {
    setCollapsedCategories(prev => ({ ...prev, [catId]: !prev[catId] }));
  };

  // Quét toàn bộ lỗi chính tả chuyên ngành trong danh sách công tác & diễn giải
  const allSpellIssues = useMemo(() => {
    if (!isSpellCheckEnabled) return [];
    const issues: SpellCheckIssue[] = [];

    for (const item of items) {
      // 1. Quét tên công tác
      const nameIssues = checkTextSpelling(item.name, item.id, 'name');
      issues.push(...nameIssues);

      // 2. Quét tên dòng diễn giải con
      for (const sub of item.subCalculations || []) {
        const subIssues = checkTextSpelling(sub.name, item.id, 'subCalcName', sub.id);
        issues.push(...subIssues);
      }
    }

    return issues;
  }, [items, isSpellCheckEnabled]);

  // Sửa 1 lỗi chính tả cụ thể
  const handleFixSingleIssue = (issue: SpellCheckIssue, suggestion: string) => {
    const item = items.find(i => i.id === issue.itemId);
    if (!item) return;

    if (issue.field === 'name') {
      const fixed = applySpellCorrection(item.name, issue.startIndex, issue.endIndex, suggestion);
      onUpdateWorkItem(item.id, { name: fixed });
    } else if (issue.field === 'subCalcName' && issue.subCalcId) {
      const sub = item.subCalculations?.find(s => s.id === issue.subCalcId);
      if (sub) {
        const fixed = applySpellCorrection(sub.name, issue.startIndex, issue.endIndex, suggestion);
        onUpdateSubCalculation(item.id, sub.id, { name: fixed });
      }
    }
  };

  // Tự động sửa TẤT CẢ các lỗi chính tả toàn bộ bảng công trình
  const handleFixAllIssues = () => {
    for (const item of items) {
      const fixedName = autoCorrectText(item.name);
      let updatedSubs: SubCalculation[] | undefined = undefined;

      if (item.subCalculations && item.subCalculations.length > 0) {
        updatedSubs = item.subCalculations.map(s => ({
          ...s,
          name: autoCorrectText(s.name)
        }));
      }

      if (fixedName !== item.name || updatedSubs) {
        onUpdateWorkItem(item.id, {
          name: fixedName,
          ...(updatedSubs ? { subCalculations: updatedSubs } : {})
        });
      }
    }
  };

  // Tính tổng toàn bộ công trình
  let totalMaterial = 0;
  let totalLabor = 0;
  let totalMachine = 0;

  items.forEach(item => {
    const q = item.quantity || 0;
    totalMaterial += q * (item.unitPriceMaterial || 0);
    totalLabor += q * (item.unitPriceLabor || 0);
    totalMachine += q * (item.unitPriceMachine || 0);
  });
  const grandTotal = totalMaterial + totalLabor + totalMachine;

  return (
    <div className="flex-1 flex flex-col h-full bg-white overflow-hidden text-xs relative select-none">
      {/* 1. Sub-Header Toolbar: Spellcheck & Search */}
      <div className="flex flex-wrap items-center justify-between px-3 py-1.5 bg-slate-100 border-b border-slate-300 gap-2">
        <div className="flex items-center gap-3">
          {/* Spellcheck Toggle */}
          <div className="flex items-center gap-2 bg-white px-2.5 py-1 rounded border border-slate-300 shadow-2xs">
            <Sparkles className={`w-3.5 h-3.5 ${isSpellCheckEnabled ? 'text-amber-500' : 'text-slate-400'}`} />
            <span className="text-[11px] font-semibold text-slate-700">Kiểm tra chính tả chuyên ngành:</span>
            <button
              onClick={() => setIsSpellCheckEnabled(!isSpellCheckEnabled)}
              className={`px-2 py-0.5 rounded text-[10px] font-bold transition-colors ${
                isSpellCheckEnabled
                  ? 'bg-amber-500 text-white'
                  : 'bg-slate-200 text-slate-600'
              }`}
            >
              {isSpellCheckEnabled ? 'ĐANG BẬT' : 'TẮT'}
            </button>
          </div>

          {/* Spellcheck Status & Action */}
          {isSpellCheckEnabled && (
            <div className="flex items-center gap-2">
              {allSpellIssues.length > 0 ? (
                <>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-bold text-[11px]">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                    Phát hiện {allSpellIssues.length} từ chưa chuẩn
                  </span>
                  <button
                    onClick={() => setShowSpellCheckDrawer(true)}
                    className="px-2.5 py-1 bg-amber-600 hover:bg-amber-500 text-white rounded text-[11px] font-bold shadow-2xs flex items-center gap-1 transition-colors"
                  >
                    <BookOpen className="w-3 h-3" />
                    Xem chi tiết & gợi ý
                  </button>
                  <button
                    onClick={handleFixAllIssues}
                    className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded text-[11px] font-bold shadow-2xs flex items-center gap-1 transition-colors"
                  >
                    <Wand2 className="w-3 h-3" />
                    Sửa tất cả ({allSpellIssues.length})
                  </button>
                </>
              ) : (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 font-medium text-[11px] border border-emerald-200">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  Chính tả chuẩn thuật ngữ TCVN
                </span>
              )}
            </div>
          )}
        </div>

        <div className="text-[11px] text-slate-500">
          Tra cứu nhanh định mức: <strong>F2</strong> | Biểu thức khối lượng: <strong>dài * rộng * cao</strong>
        </div>
      </div>

      {/* 2. Main Work Items Spreadsheet Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full border-collapse border border-slate-300 table-auto select-text">
          <thead className="sticky top-0 z-10 bg-slate-100 shadow-xs">
            <tr className="border-b border-slate-300">
              <th rowSpan={2} className="f1-header-cell w-10">STT</th>
              <th rowSpan={2} className="f1-header-cell w-24">Mã hiệu</th>
              <th rowSpan={2} className="f1-header-cell min-w-[260px] text-left px-3">Tên công tác & quy cách</th>
              <th rowSpan={2} className="f1-header-cell w-16">Đơn vị</th>
              <th rowSpan={2} className="f1-header-cell w-24">Khối lượng</th>
              <th colSpan={3} className="f1-header-cell">Đơn giá gốc (VNĐ)</th>
              <th colSpan={4} className="f1-header-cell">Thành tiền (VNĐ)</th>
              <th rowSpan={2} className="f1-header-cell w-16">Thao tác</th>
            </tr>
            <tr className="border-b border-slate-300 bg-slate-50">
              <th className="f1-header-cell w-24">Vật liệu</th>
              <th className="f1-header-cell w-24">Nhân công</th>
              <th className="f1-header-cell w-24">Máy</th>
              <th className="f1-header-cell w-28">Vật liệu</th>
              <th className="f1-header-cell w-28">Nhân công</th>
              <th className="f1-header-cell w-28">Máy</th>
              <th className="f1-header-cell w-32 bg-slate-200 font-bold">Tổng cộng</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((cat, catIdx) => {
              const catItems = items.filter(item => item.categoryId === cat.id);
              const isCollapsed = collapsedCategories[cat.id];

              let catMat = 0;
              let catLab = 0;
              let catMac = 0;
              catItems.forEach(i => {
                const q = i.quantity || 0;
                catMat += q * i.unitPriceMaterial;
                catLab += q * i.unitPriceLabor;
                catMac += q * i.unitPriceMachine;
              });
              const catTotal = catMat + catLab + catMac;

              return (
                <React.Fragment key={cat.id}>
                  {/* Category Header Row */}
                  <tr className="bg-slate-200/90 font-bold text-slate-800 border-y border-slate-300">
                    <td className="f1-cell text-center">{catIdx + 1}</td>
                    <td className="f1-cell text-center text-slate-600 font-mono text-[11px]">HM.{catIdx + 1}</td>
                    <td colSpan={6} className="f1-cell px-3">
                      <button
                        onClick={() => toggleCategory(cat.id)}
                        className="flex items-center gap-1.5 hover:text-blue-700 text-left font-bold"
                      >
                        {isCollapsed ? <ChevronRight className="w-3.5 h-3.5 text-slate-500" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-500" />}
                        <span>{cat.name.toUpperCase()}</span>
                      </button>
                    </td>
                    <td className="f1-cell text-right tabular-nums">{formatVND(catMat)}</td>
                    <td className="f1-cell text-right tabular-nums">{formatVND(catLab)}</td>
                    <td className="f1-cell text-right tabular-nums">{formatVND(catMac)}</td>
                    <td className="f1-cell text-right tabular-nums font-bold text-slate-900 bg-slate-300/50">
                      {formatVND(catTotal)}
                    </td>
                    <td className="f1-cell text-center"></td>
                  </tr>

                  {/* Work Items in this Category */}
                  {!isCollapsed &&
                    catItems.map((item) => {
                      const isSelected = selectedItemId === item.id && !selectedSubCalcId;
                      const q = item.quantity || 0;
                      const tMat = q * item.unitPriceMaterial;
                      const tLab = q * item.unitPriceLabor;
                      const tMac = q * item.unitPriceMachine;
                      const tTotal = tMat + tLab + tMac;

                      // Lấy các lỗi chính tả của riêng công tác này
                      const itemIssues = isSpellCheckEnabled
                        ? allSpellIssues.filter(i => i.itemId === item.id && i.field === 'name')
                        : [];

                      return (
                        <React.Fragment key={item.id}>
                          <tr
                            onClick={() => onSelectItem(item)}
                            className={`cursor-pointer transition-colors ${
                              isSelected ? 'bg-blue-50/80 ring-1 ring-blue-400' : 'hover:bg-slate-50/90'
                            }`}
                          >
                            <td className="f1-cell text-center text-slate-500 font-mono">{item.stt}</td>
                            <td className="f1-cell text-center font-mono font-medium text-blue-700">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onOpenNormLookupForWorkItem(item.id);
                                }}
                                className="hover:underline flex items-center justify-center gap-1 mx-auto"
                                title="Nhấn để tra cứu và thay đổi định mức"
                              >
                                <span>{item.code}</span>
                                <Search className="w-2.5 h-2.5 text-slate-400" />
                              </button>
                            </td>

                            {/* Tên công tác với gợi ý sửa chính tả */}
                            <td className="f1-cell px-3 relative">
                              <div className="flex flex-col">
                                <input
                                  type="text"
                                  value={item.name}
                                  onChange={(e) => onUpdateWorkItem(item.id, { name: e.target.value })}
                                  className={`w-full bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded text-slate-900 font-medium ${
                                    itemIssues.length > 0 ? 'border-b-2 border-dashed border-amber-500' : ''
                                  }`}
                                />
                                {/* Quick Fix Chips if typo detected */}
                                {itemIssues.length > 0 && (
                                  <div className="flex flex-wrap items-center gap-1 mt-0.5">
                                    {itemIssues.map((issue, issueIdx) => (
                                      <button
                                        key={`${issue.id}-${issueIdx}`}
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleFixSingleIssue(issue, issue.suggestions[0]);
                                        }}
                                        className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded bg-amber-100 hover:bg-amber-200 text-amber-800 text-[10px] font-semibold border border-amber-300 transition-colors"
                                        title={`Nhấn để sửa thành "${issue.suggestions[0]}"`}
                                      >
                                        <Wand2 className="w-2.5 h-2.5 text-amber-600" />
                                        <span>Gợi ý: <strong>{issue.suggestions[0]}</strong></span>
                                      </button>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </td>

                            <td className="f1-cell text-center text-slate-600">
                              <input
                                type="text"
                                value={item.unit}
                                onChange={(e) => onUpdateWorkItem(item.id, { unit: e.target.value })}
                                className="w-full text-center bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded text-slate-700 font-mono text-[11px]"
                              />
                            </td>
                            <td className="f1-cell text-right tabular-nums font-semibold text-slate-900 bg-amber-50/30">
                              <input
                                type="number"
                                step="any"
                                value={item.quantity}
                                onChange={(e) => onUpdateWorkItem(item.id, { quantity: parseFloat(e.target.value) || 0 })}
                                className="w-full text-right bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded font-mono"
                              />
                            </td>
                            <td className="f1-cell text-right tabular-nums text-slate-700">
                              <input
                                type="number"
                                value={item.unitPriceMaterial}
                                onChange={(e) => onUpdateWorkItem(item.id, { unitPriceMaterial: parseFloat(e.target.value) || 0 })}
                                className="w-full text-right bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded font-mono"
                              />
                            </td>
                            <td className="f1-cell text-right tabular-nums text-slate-700">
                              <input
                                type="number"
                                value={item.unitPriceLabor}
                                onChange={(e) => onUpdateWorkItem(item.id, { unitPriceLabor: parseFloat(e.target.value) || 0 })}
                                className="w-full text-right bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded font-mono"
                              />
                            </td>
                            <td className="f1-cell text-right tabular-nums text-slate-700">
                              <input
                                type="number"
                                value={item.unitPriceMachine}
                                onChange={(e) => onUpdateWorkItem(item.id, { unitPriceMachine: parseFloat(e.target.value) || 0 })}
                                className="w-full text-right bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded font-mono"
                              />
                            </td>
                            <td className="f1-cell text-right tabular-nums text-slate-800">{formatVND(tMat)}</td>
                            <td className="f1-cell text-right tabular-nums text-slate-800">{formatVND(tLab)}</td>
                            <td className="f1-cell text-right tabular-nums text-slate-800">{formatVND(tMac)}</td>
                            <td className="f1-cell text-right tabular-nums font-bold text-slate-900 bg-slate-100">
                              {formatVND(tTotal)}
                            </td>
                            <td className="f1-cell text-center">
                              <div className="flex items-center justify-center gap-1">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onAddSubCalculation(item.id);
                                  }}
                                  title="Chèn dòng diễn giải kích thước"
                                  className="p-1 text-slate-400 hover:text-amber-600 rounded"
                                >
                                  <Plus className="w-3 h-3" />
                                </button>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onDeleteWorkItem(item.id);
                                  }}
                                  title="Xóa công tác"
                                  className="p-1 text-slate-400 hover:text-red-600 rounded"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            </td>
                          </tr>

                          {/* Sub-calculations / Diễn giải con */}
                          {item.subCalculations && item.subCalculations.map((sub, sIdx) => {
                            const isSubSelected = selectedSubCalcId === sub.id;
                            const subIssues = isSpellCheckEnabled
                              ? allSpellIssues.filter(i => i.subCalcId === sub.id)
                              : [];

                            return (
                              <tr
                                key={sub.id}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onSelectItem(item, sub);
                                }}
                                className={`text-[11px] cursor-pointer ${
                                  isSubSelected ? 'bg-amber-100/70 ring-1 ring-amber-400' : 'bg-slate-50/50 hover:bg-amber-50/40'
                                }`}
                              >
                                <td className="f1-cell text-center text-slate-300 font-mono">{`${item.stt}.${sIdx + 1}`}</td>
                                <td className="f1-cell text-center text-slate-400 font-mono text-[10px]">DG</td>
                                <td className="f1-cell pl-8 pr-3 text-slate-700">
                                  <div className="flex flex-col">
                                    <div className="flex items-center gap-2">
                                      <span className="text-slate-400 select-none">-</span>
                                      <input
                                        type="text"
                                        value={sub.name}
                                        onChange={(e) => onUpdateSubCalculation(item.id, sub.id, { name: e.target.value })}
                                        className={`flex-1 bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded text-slate-700 italic ${
                                          subIssues.length > 0 ? 'border-b border-dashed border-amber-500' : ''
                                        }`}
                                      />
                                      <span className="text-slate-400">:</span>
                                      <input
                                        type="text"
                                        value={sub.expression}
                                        onChange={(e) => {
                                          const expr = e.target.value;
                                          const qty = evaluateMathExpression(expr);
                                          onUpdateSubCalculation(item.id, sub.id, { expression: expr, quantity: qty });
                                        }}
                                        className="w-48 font-mono bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded text-blue-800"
                                      />
                                    </div>
                                    {subIssues.length > 0 && (
                                      <div className="flex items-center gap-1 mt-0.5 pl-4">
                                        {subIssues.map((issue, issueIdx) => (
                                          <button
                                            key={`${issue.id}-${issueIdx}`}
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              handleFixSingleIssue(issue, issue.suggestions[0]);
                                            }}
                                            className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded bg-amber-100 hover:bg-amber-200 text-amber-800 text-[10px] font-semibold border border-amber-300 transition-colors"
                                          >
                                            <Wand2 className="w-2.5 h-2.5 text-amber-600" />
                                            <span>Sửa: <strong>{issue.suggestions[0]}</strong></span>
                                          </button>
                                        ))}
                                      </div>
                                    )}
                                  </div>
                                </td>
                                <td className="f1-cell text-center text-slate-400">{item.unit}</td>
                                <td className="f1-cell text-right tabular-nums text-slate-700 font-mono font-medium">
                                  {formatQuantity(sub.quantity)}
                                </td>
                                <td colSpan={7} className="f1-cell text-slate-300 bg-slate-50/20"></td>
                                <td className="f1-cell text-center">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onDeleteSubCalculation(item.id, sub.id);
                                    }}
                                    title="Xóa dòng diễn giải"
                                    className="p-1 text-slate-400 hover:text-red-500 rounded"
                                  >
                                    <Trash2 className="w-2.5 h-2.5" />
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </React.Fragment>
                      );
                    })}
                </React.Fragment>
              );
            })}
          </tbody>
          <tfoot className="sticky bottom-0 z-10 bg-slate-900 text-white font-bold text-xs shadow-md">
            <tr className="border-t-2 border-slate-700">
              <td colSpan={4} className="f1-cell text-center py-2 text-slate-300">
                TỔNG CỘNG TOÀN BỘ CÔNG TRÌNH (TRƯỚC THUẾ)
              </td>
              <td className="f1-cell text-center text-slate-400 font-mono">{items.length} công tác</td>
              <td colSpan={3} className="f1-cell text-slate-500"></td>
              <td className="f1-cell text-right tabular-nums text-slate-200">{formatVND(totalMaterial)}</td>
              <td className="f1-cell text-right tabular-nums text-slate-200">{formatVND(totalLabor)}</td>
              <td className="f1-cell text-right tabular-nums text-slate-200">{formatVND(totalMachine)}</td>
              <td className="f1-cell text-right tabular-nums text-emerald-400 font-bold bg-slate-800 text-sm">
                {formatVND(grandTotal)}
              </td>
              <td className="f1-cell text-center"></td>
            </tr>
          </tfoot>
        </table>
      </div>

      {/* 3. Sheet Bottom Summary Bar */}
      <div className="flex items-center justify-between px-3 py-1 bg-slate-100 border-t border-slate-300 text-[11px] text-slate-600">
        <div className="flex items-center gap-3">
          <span>Nhấn <strong>Tra định mức (F2)</strong> để chọn từ thư viện TT 12</span>
          <span>·</span>
          <span>Chèn dòng diễn giải để tính kích thước dài x rộng x cao</span>
          <span>·</span>
          <span>Từ điển chuẩn hóa xây dựng: <strong>{CONSTRUCTION_STANDARD_LEXICON.size} thuật ngữ TCVN</strong></span>
        </div>
        <div className="font-mono text-slate-700">
          Tổng chi phí xây dựng trực tiếp: <strong className="text-slate-900">{formatVND(grandTotal)} VNĐ</strong>
        </div>
      </div>

      {/* 4. Spellcheck Drawer / Modal */}
      {showSpellCheckDrawer && (
        <div className="fixed inset-y-0 right-0 w-96 bg-white shadow-2xl border-l border-slate-300 z-50 flex flex-col animate-in slide-in-from-right duration-200 text-xs">
          <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-amber-400" />
              <span className="font-bold text-sm">Từ Điển & Gợi Ý Sửa Chính Tả</span>
            </div>
            <button
              onClick={() => setShowSpellCheckDrawer(false)}
              className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="p-3 bg-amber-50 border-b border-amber-200 text-amber-900 leading-snug flex items-center justify-between">
            <div>
              Phát hiện <strong>{allSpellIssues.length} vị trí</strong> cần chuẩn hóa chính tả chuyên ngành xây dựng.
            </div>
            {allSpellIssues.length > 0 && (
              <button
                onClick={handleFixAllIssues}
                className="px-2 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded font-bold text-[11px] shrink-0 ml-2"
              >
                Sửa tất cả
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {allSpellIssues.length === 0 ? (
              <div className="text-center py-10 text-slate-400 space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
                <p className="font-semibold text-slate-600">Không có lỗi chính tả nào!</p>
                <p className="text-[11px]">Tất cả tên công tác và diễn giải đều chuẩn theo từ điển TCVN.</p>
              </div>
            ) : (
              allSpellIssues.map((issue, idx) => (
                <div key={`${issue.id}-${idx}`} className="p-3 rounded-lg border border-slate-200 bg-slate-50 space-y-2">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-mono text-slate-500">#{idx + 1} ({issue.field === 'name' ? 'Tên công tác' : 'Diễn giải'})</span>
                    <span className="text-rose-600 font-bold bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                      "{issue.misspelledWord}"
                    </span>
                  </div>

                  <div className="text-slate-600 text-[11px] italic bg-white p-2 rounded border border-slate-200">
                    "...{issue.originalText.substring(Math.max(0, issue.startIndex - 15), Math.min(issue.originalText.length, issue.endIndex + 15))}..."
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[11px] text-slate-500">Gợi ý chuẩn TCVN:</span>
                    <div className="flex items-center gap-1">
                      {issue.suggestions.map((sug, sIdx) => (
                        <button
                          key={`${issue.id}-sug-${sIdx}-${sug}`}
                          onClick={() => handleFixSingleIssue(issue, sug)}
                          className="px-2 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded font-bold text-[11px] flex items-center gap-1 shadow-2xs"
                        >
                          <Check className="w-3 h-3" />
                          <span>{sug}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

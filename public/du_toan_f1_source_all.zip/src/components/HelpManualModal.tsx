import React, { useState } from 'react';
import { 
  HelpCircle, BookOpen, Search, X, CheckCircle2, 
  Keyboard, FileText, Download, Sparkles, ExternalLink,
  ChevronRight, Layers, Sliders, Printer, Code, QrCode,
  TrendingUp, ShieldCheck, Check, Info, ArrowRight
} from 'lucide-react';

interface HelpManualModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenUpdateModal?: () => void;
}

interface HelpTopic {
  id: string;
  category: string;
  title: string;
  summary: string;
  shortcut?: string;
  icon: string;
  steps: string[];
  tips: string[];
  regulations?: string;
}

const HELP_TOPICS: HelpTopic[] = [
  {
    id: 'workflow',
    category: 'Quy trình cơ bản',
    title: 'Quy trình lập dự toán 5 bước chuẩn Bộ Xây dựng',
    summary: 'Hướng dẫn tuần tự từ khâu tra cứu mã định mức, bóc tách khối lượng, áp giá tháng đến tổng hợp kinh phí.',
    icon: '📋',
    regulations: 'Nghị định 10/2021/NĐ-CP & Thông tư 11/2021/TT-BXD',
    steps: [
      'Bước 1 - Lập bảng khối lượng (Tab Công trình): Nhấn F2 để tra cứu mã hiệu định mức theo Thông tư 12/2021/TT-BXD. Nhập diễn giải khối lượng chi tiết (dài × rộng × cao).',
      'Bước 2 - Phân tích vật tư (Tab PTVT): Hệ thống tự động bóc tách hao phí định mức Vật liệu, Nhân công, Máy thi công cho từng đơn vị công tác.',
      'Bước 3 - Áp giá tháng & Bù giá (Tab THVT): Sử dụng nút "Lắp giá tháng Sở XD" để nạp giá công bố mới nhất của 63 Tỉnh/Thành phố hoặc nhập giá thị trường thực tế.',
      'Bước 4 - Xác định đơn giá chi tiết & Dự thầu (Tab DGCT & Dự thầu): Tính toán đơn giá xây dựng chi tiết không đầy đủ và đầy đủ phục vụ đấu thầu theo Luật Đấu thầu số 22/2023/QH15.',
      'Bước 5 - Tổng hợp kinh phí dự toán (Tab THKP): Hệ thống tự động tính chi phí gián tiếp, thu nhập chịu thuế tính trước, thuế VAT và tổng mức đầu tư theo Thông tư 11/2021/TT-BXD.'
    ],
    tips: [
      'Nhấn phím F2 bất kỳ lúc nào để mở hộp thoại tra cứu mã hiệu định mức nhanh.',
      'Sử dụng nút "Mẫu chuẩn" trên thanh tiêu đề nếu muốn khôi phục dữ liệu dự án mẫu tiêu chuẩn của F1 Pro.'
    ]
  },
  {
    id: 'cong-trinh',
    category: 'Bảng Công trình',
    title: 'Quản lý khối lượng, diễn giải con & Kiểm tra chính tả TCVN',
    summary: 'Cách nhập số liệu, công thức toán học kích thước và sử dụng trợ lý chính tả chuyên ngành xây dựng.',
    shortcut: 'F2',
    icon: '🏗️',
    regulations: 'Thông tư 12/2021/TT-BXD & Tiêu chuẩn Quốc gia TCVN',
    steps: [
      'Tra cứu mã hiệu: Nhấn "Tra định mức (F2)" hoặc bấm đúp vào ô Mã hiệu để tìm kiếm theo mã (AA, AB, AF, AK...) hoặc từ khóa tên công việc.',
      'Chèn diễn giải kích thước: Nhấn "Chèn diễn giải KL" để thêm các dòng cấu kiện chi tiết (ví dụ: "Móng M1", "Dầm D1"). Nhập biểu thức dạng "12 * 1.8 * 1.8 * 0.6", phần mềm sẽ tự động tính ra kết quả.',
      'Kiểm tra chính tả chuyên ngành: Tính năng kiểm tra chính tả xây dựng tự động phát hiện các từ gõ sai, thiếu dấu tiếng Việt hoặc sai thuật ngữ (ví dụ: "mac 200" -> "mác 200", "vua" -> "vữa", "be tong" -> "bê tông").',
      'Sửa lỗi 1 chạm: Nhấn trực tiếp vào chip "Gợi ý" dưới tên công tác để sửa ngay, hoặc bấm "Sửa tất cả" trong ngăn kéo để chuẩn hóa toàn bộ dự toán.'
    ],
    tips: [
      'Có thể nhập công thức phức tạp trong FormulaBar với các dấu ngoặc đơn () và toán tử +, -, *, /.',
      'Các hạng mục công việc có thể thu gọn/mở rộng bằng cách nhấn vào mũi tên đầu dòng hạng mục.'
    ]
  },
  {
    id: 'thvt',
    category: 'Vật tư & Giá tháng',
    title: 'Lắp giá thông báo Sở Xây dựng 63 Tỉnh/Thành & Bù chênh lệch',
    summary: 'Tự động áp giá vật liệu, đơn giá nhân công theo vùng lương và giá ca máy thi công.',
    icon: '🪙',
    regulations: 'Thông tư 11/2021/TT-BXD & TT 13/2021/TT-BXD',
    steps: [
      'Chọn Tỉnh/Thành phố: Chọn nhanh tỉnh cần lập dự toán tại góc trên bên trái thanh Ribbon (hỗ trợ đầy đủ 63 tỉnh thành).',
      'Lắp giá tháng tự động: Nhấn nút "Lắp giá tháng Sở XD", chọn tháng/quý công bố của địa phương và bấm "Áp dụng giá tháng cho toàn bộ dự án".',
      'Tự động tính chênh lệch: Cột "Chênh lệch" và "Thành tiền chênh lệch" trong sheet THVT sẽ tự động tính: Giá tháng - Giá gốc.',
      'Bù giá vào THKP: Toàn bộ chênh lệch vật tư được tự động cập nhật trực tiếp vào dòng Chi phí vật liệu trong sheet Tổng hợp kinh phí.'
    ],
    tips: [
      'Có thể sửa trực tiếp đơn giá tháng của từng vật liệu trong bảng Tổng hợp vật tư.',
      'Hệ số nhân công và máy thi công được tự động điều chỉnh theo vùng lương (Vùng I, II, III, IV) của địa phương đã chọn.'
    ]
  },
  {
    id: 'thkp-auto',
    category: 'Tổng hợp kinh phí',
    title: 'Tự động hóa tính toán Chi phí gián tiếp & Xuất mã QR Code',
    summary: 'Nội suy tuyến tính tỷ lệ chi phí chung (C), chi phí nhà tạm (NT) và xuất mã QR Code xem trên điện thoại.',
    icon: '📊',
    regulations: 'Thông tư 11/2021/TT-BXD Bảng 3.1 & 3.2',
    steps: [
      'Chọn loại công trình chủ đạo: Dân dụng (7.3% - 4.4%), Công nghiệp (6.2% - 4.1%), Giao thông (5.5% - 3.8%), Nông nghiệp (5.8% - 4.0%), Hạ tầng kỹ thuật (5.0% - 3.4%).',
      'Phương pháp tính: Chọn "Nội suy tự động theo quy mô T" (hệ thống tự động tra bảng 3.1) hoặc "Phân bổ theo từng hạng mục công trình" nếu dự án có nhiều loại công trình kết hợp.',
      'Công trình theo tuyến: Bật tùy chọn "Công trình theo tuyến" để chi phí nhà tạm tự động nâng lên 2.2% (thay vì 1.2% cho công trình tại chỗ).',
      'Xuất QR Code di động: Nhấn "Xuất QR Code Di Động" để tạo mã QR chứa toàn bộ thông số kinh phí tóm tắt. Dùng điện thoại quét mã để xem giao diện Mobile Summary tức thì.'
    ],
    tips: [
      'Nhấn vào nút "Bảng tra định mức TT11" để xem chi tiết bảng mốc tỷ lệ chi phí chung từ dưới 15 tỷ đến trên 1.000 tỷ.',
      'Có thể in thẻ QR Code công trường (A5/A6) để phát cho cán bộ giám sát và chỉ huy trưởng.'
    ]
  },
  {
    id: 'tham-tra',
    category: 'Thẩm tra dự toán',
    title: 'So sánh 2 phiên bản dự toán & Xuất báo cáo sai lệch',
    summary: 'Kiểm tra chênh lệch khối lượng và đơn giá giữa hồ sơ trình duyệt và hồ sơ sau thẩm tra, xuất biên bản 01/TTr.',
    icon: '🔍',
    regulations: 'Nghị định 10/2021/NĐ-CP về Quản lý chi phí đầu tư xây dựng',
    steps: [
      'Chế độ xem so sánh: Chuyển đổi giữa "Chế độ Thẩm tra khối lượng" và "So sánh 2 Phiên bản (Dự toán vs Quyết toán)".',
      'Phát hiện sai lệch vượt định mức: Các công tác có khối lượng thẩm tra giảm hoặc tăng được đánh dấu màu sắc cảnh báo trực quan.',
      'Áp dụng kết quả thẩm tra: Nhấn "Áp dụng toàn bộ số liệu thẩm tra vào Dự toán" để đồng bộ số liệu chuẩn vào bảng Công trình.',
      'Xuất Báo cáo thẩm tra PDF: Nhấn "In Biên bản Thẩm tra (Mẫu 01/TTr)" để xuất văn bản kết quả thẩm tra chính thức kèm số hiệu công văn và chữ ký đại diện.'
    ],
    tips: [
      'Hệ thống tự động lọc nhanh các mục có sai lệch để thẩm tra viên đối chiếu nhanh chóng.'
    ]
  },
  {
    id: 'risk-d3',
    category: 'Phân tích rủi ro',
    title: 'Mô phỏng biến động chi phí Monte Carlo & Biểu đồ D3 S-Curve',
    summary: 'Dự báo khả năng vượt ngân sách dự toán và phân tích dòng tiền giải ngân lũy kế theo thời gian.',
    icon: '📈',
    regulations: 'Phương pháp phân tích rủi ro tài chính dự án đầu tư xây dựng',
    steps: [
      'Chọn kịch bản mô phỏng: Kịch bản Cơ sở (Baseline), Lạc quan (-5% đến -8%), Thận trọng (+8% đến +15%) hoặc Xấu nhất (+20% đến +25%).',
      'Điều chỉnh các tham số rủi ro: Trượt giá vật liệu thép & xi măng, biến động giá nhiên liệu, rủi ro địa chất ngầm, chậm tiến độ mặt bằng.',
      'Phân tích biểu đồ phân phối xác suất D3: Biểu đồ đường cong mật độ chuẩn hiển thị xác suất dự toán nằm trong các khoảng ngân sách (P50, P80, P90).',
      'Biểu đồ dòng tiền lũy kế (S-Curve): Trực quan hóa tiến độ giải ngân theo từng tháng thi công và so sánh mức chênh lệch giữa kế hoạch và kịch bản rủi ro.'
    ],
    tips: [
      'Mức ngân sách P80 là mức an toàn được các tổ chức tài chính quốc tế khuyến nghị sử dụng khi phê duyệt tổng mức đầu tư.'
    ]
  },
  {
    id: 'admin-pdf',
    category: 'In ấn & Xuất bản',
    title: 'Xuất toàn bộ bảng tính ra file PDF theo mẫu Hành chính Nhà nước',
    summary: 'Chuẩn thể thức Nghị định 30/2020/NĐ-CP với Quốc hiệu, Tiêu ngữ, Bảng kẻ và 4 vị trí chữ ký duyệt.',
    shortcut: 'Ctrl + P',
    icon: '🏛️',
    regulations: 'Nghị định 30/2020/NĐ-CP về Công tác văn thư hành chính',
    steps: [
      'Mở giao diện In ấn: Nhấn nút "Xuất PDF Hành chính" màu đỏ trên thanh Ribbon hoặc trong sheet THKP.',
      'Chọn Bảng tính cần xuất: Cho phép in bảng tính hiện tại hoặc chuyển đổi sang bất kỳ sheet nào (THKP, Công trình, THVT, DGCT, Dự thầu, Thẩm tra...).',
      'Chọn khổ giấy: Chọn A4 Ngang (Landscape - phù hợp bảng nhiều cột số liệu) hoặc A4 Dọc (Portrait).',
      'Tùy chỉnh thông tin hành chính: Nhấn "Sửa Tiêu đề & Đơn vị" để nhập cơ quan chủ quản, tên đơn vị tư vấn, tên Ban QLDA, họ tên người lập, chủ trì, người duyệt và địa danh ngày tháng.',
      'In hoặc Lưu PDF: Nhấn "IN ẤN / XUẤT RA FILE PDF" để mở hộp thoại in của trình duyệt (chọn Save as PDF), hoặc nhấn "Tải file HTML" để lưu file độc lập.'
    ],
    tips: [
      'Các trường thông tin hành chính đã nhập trong ProjectSettings sẽ được lưu tự động cho mọi lần xuất bản sau.'
    ]
  },
  {
    id: 'python-api',
    category: 'Mã nguồn & API',
    title: 'Xuất gói mã nguồn Python & Kết nối REST API (Bảo mật)',
    summary: 'Hướng dẫn sử dụng engine Python độc lập, database SQLite và mật khẩu bản quyền bảo vệ.',
    icon: '🐍',
    regulations: 'Kiến trúc phần mềm mở & Tích hợp Revit / AutoCAD / BIM',
    steps: [
      'Mở trung tâm Python: Nhấn nút "Xuất mã Python & API" trên thanh Ribbon.',
      'Nhập mật khẩu ủy quyền: Chức năng được bảo vệ bản quyền. Nhập chính xác mật khẩu ủy quyền để mở khóa tải xuống.',
      'Tải gói mã nguồn: Sau khi mở khóa, người dùng có thể tải gói Python độc lập (gồm engine tính toán, SQLite database TT12, CLI 15 menu, xuất Excel 8 sheet) hoặc gói Full Source Code (.zip).',
      'Chạy REST API Server: Khởi chạy `python app.py` để mở máy chủ cổng 8000, hỗ trợ đồng bộ dữ liệu hai chiều với Autodesk Revit và hệ thống ERP.'
    ],
    tips: [
      'Mật khẩu ủy quyền hợp lệ được cấp cho quản trị viên hệ thống.',
      'Sau khi mở khóa, hệ thống sẽ duy trì quyền truy cập trong suốt phiên làm việc.'
    ]
  }
];

const KEYBOARD_SHORTCUTS = [
  { key: 'F1', desc: 'Mở cửa sổ Hướng dẫn sử dụng phần mềm (Help)', group: 'Hệ thống' },
  { key: 'F2', desc: 'Mở cửa sổ Tra cứu mã hiệu định mức Bộ Xây dựng', group: 'Thao tác' },
  { key: 'Ctrl + P', desc: 'Xuất toàn bộ bảng tính hiện tại ra PDF mẫu hành chính nhà nước', group: 'Xuất bản' },
  { key: 'Ctrl + E', desc: 'Xuất trọn bộ 8 sheet dự toán ra file Excel (.xlsx)', group: 'Xuất bản' },
  { key: 'Ctrl + S', desc: 'Mở cấu hình dự án và lưu tham số hệ số', group: 'Hệ thống' },
  { key: 'Alt + 1..9', desc: 'Chuyển nhanh giữa các tab phân hệ dự toán (1: Công trình, 6: THKP...)', group: 'Điều hướng' },
];

export const HelpManualModal: React.FC<HelpManualModalProps> = ({
  isOpen,
  onClose,
  onOpenUpdateModal
}) => {
  const [selectedTopicId, setSelectedTopicId] = useState<string>('workflow');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'topics' | 'shortcuts' | 'regulations'>('topics');

  if (!isOpen) return null;

  // Lọc theo từ khóa tìm kiếm
  const filteredTopics = HELP_TOPICS.filter(t => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      t.title.toLowerCase().includes(q) ||
      t.summary.toLowerCase().includes(q) ||
      t.category.toLowerCase().includes(q) ||
      t.steps.some(s => s.toLowerCase().includes(q))
    );
  });

  const selectedTopic = HELP_TOPICS.find(t => t.id === selectedTopicId) || HELP_TOPICS[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 select-none animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-5xl h-[90vh] flex flex-col text-slate-800 overflow-hidden">
        {/* Header Modal */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white shrink-0 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <span className="p-2 bg-blue-600/30 text-blue-400 rounded-xl border border-blue-500/40">
              <HelpCircle className="w-5 h-5" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm tracking-tight text-white uppercase flex items-center gap-2">
                  <span>HƯỚNG DẪN SỬ DỤNG PHẦN MỀM DỰ TOÁN F1 PRO</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-950 text-blue-400 border border-blue-800 font-mono font-bold">
                    Menu Help (F1)
                  </span>
                </h3>
              </div>
              <p className="text-[11px] text-slate-400">
                Sổ tay hướng dẫn thao tác, quy chuẩn lập dự toán BXD, danh mục phím tắt và tài liệu kỹ thuật
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {onOpenUpdateModal && (
              <button
                onClick={() => {
                  onClose();
                  onOpenUpdateModal();
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all shadow-xs cursor-pointer"
                title="Kiểm tra bản cập nhật mới nhất"
              >
                <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                <span>Trung tâm Update (v2026.4)</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Sub Header / Search & Tabs */}
        <div className="px-6 py-3 bg-slate-100 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="relative w-full max-w-sm">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm kiếm hướng dẫn (VD: tra định mức, chi phí chung, in PDF...)"
              className="w-full pl-9 pr-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs focus:outline-hidden focus:ring-2 focus:ring-blue-500/30 focus:border-blue-500 placeholder:text-slate-400"
            />
          </div>

          <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-200 text-xs">
            <button
              onClick={() => setActiveTab('topics')}
              className={`px-3 py-1 rounded-md font-semibold transition-colors cursor-pointer ${
                activeTab === 'topics' ? 'bg-blue-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Chủ đề Hướng dẫn
            </button>
            <button
              onClick={() => setActiveTab('shortcuts')}
              className={`px-3 py-1 rounded-md font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'shortcuts' ? 'bg-blue-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Keyboard className="w-3.5 h-3.5" />
              <span>Phím tắt (Shortcuts)</span>
            </button>
            <button
              onClick={() => setActiveTab('regulations')}
              className={`px-3 py-1 rounded-md font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'regulations' ? 'bg-blue-600 text-white shadow-2xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Hệ thống Thông tư BXD</span>
            </button>
          </div>
        </div>

        {/* Modal Main Content */}
        <div className="flex-1 flex overflow-hidden">
          {activeTab === 'topics' && (
            <>
              {/* Left Sidebar: Topics list */}
              <div className="w-80 border-r border-slate-200 bg-slate-50/70 overflow-y-auto p-3 space-y-1.5 shrink-0">
                <div className="px-2 py-1 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  DANH MỤC PHÂN HỆ ({filteredTopics.length})
                </div>
                {filteredTopics.map((topic) => {
                  const isSelected = topic.id === selectedTopic.id;
                  return (
                    <button
                      key={topic.id}
                      onClick={() => setSelectedTopicId(topic.id)}
                      className={`w-full text-left p-2.5 rounded-xl text-xs transition-all flex items-start gap-2.5 cursor-pointer border ${
                        isSelected
                          ? 'bg-blue-50/90 border-blue-300 text-blue-900 shadow-xs font-semibold'
                          : 'border-transparent hover:bg-slate-200/60 text-slate-700'
                      }`}
                    >
                      <span className="text-base leading-none mt-0.5">{topic.icon}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] text-slate-500 font-mono">{topic.category}</span>
                          {topic.shortcut && (
                            <span className="text-[9px] px-1 py-0.2 bg-slate-200 text-slate-700 rounded font-mono font-bold">
                              {topic.shortcut}
                            </span>
                          )}
                        </div>
                        <div className="font-semibold truncate text-[11.5px] mt-0.5">{topic.title}</div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Right Content: Topic Details */}
              <div className="flex-1 overflow-y-auto p-6 bg-white space-y-6">
                <div className="space-y-2 border-b border-slate-200 pb-4">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{selectedTopic.icon}</span>
                    <div>
                      <span className="text-[11px] font-bold text-blue-600 uppercase tracking-wider">
                        {selectedTopic.category}
                      </span>
                      <h2 className="text-base font-bold text-slate-900 tracking-tight">
                        {selectedTopic.title}
                      </h2>
                    </div>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {selectedTopic.summary}
                  </p>
                  {selectedTopic.regulations && (
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-amber-50 text-amber-800 rounded-md border border-amber-200 text-[11px] font-medium">
                      <Info className="w-3.5 h-3.5 text-amber-600" />
                      <span>Căn cứ pháp lý: <strong>{selectedTopic.regulations}</strong></span>
                    </div>
                  )}
                </div>

                {/* Steps Section */}
                <div className="space-y-3">
                  <h4 className="font-bold text-xs text-slate-900 uppercase flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Các bước thực hiện chi tiết:</span>
                  </h4>
                  <div className="space-y-2.5">
                    {selectedTopic.steps.map((step, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200/80 text-xs text-slate-700 leading-relaxed"
                      >
                        <span className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <div>{step}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Tips & Pro Notes */}
                {selectedTopic.tips.length > 0 && (
                  <div className="p-4 bg-blue-50/70 border border-blue-200 rounded-xl space-y-2">
                    <h5 className="font-bold text-xs text-blue-900 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-blue-600" />
                      <span>Mẹo &amp; Lưu ý quan trọng từ Kỹ sư Định giá F1:</span>
                    </h5>
                    <ul className="space-y-1.5 text-xs text-blue-950 pl-5 list-disc">
                      {selectedTopic.tips.map((tip, idx) => (
                        <li key={idx} className="leading-relaxed">{tip}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </>
          )}

          {activeTab === 'shortcuts' && (
            <div className="flex-1 overflow-y-auto p-6 bg-white space-y-5">
              <div className="space-y-1 border-b pb-3">
                <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <Keyboard className="w-4 h-4 text-blue-600" />
                  <span>BẢNG DANH MỤC PHÍM TẮT HỆ THỐNG (HOTKEYS)</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Tăng tốc độ bóc tách khối lượng và lập dự toán chuyên nghiệp với các phím tắt nhanh
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {KEYBOARD_SHORTCUTS.map((sc, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-200 hover:border-blue-300 transition-colors"
                  >
                    <div className="space-y-1">
                      <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded bg-slate-200 text-slate-600">
                        {sc.group}
                      </span>
                      <p className="text-xs text-slate-700 font-medium">{sc.desc}</p>
                    </div>
                    <kbd className="px-2.5 py-1 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-blue-700 shadow-2xs whitespace-nowrap">
                      {sc.key}
                    </kbd>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'regulations' && (
            <div className="flex-1 overflow-y-auto p-6 bg-white space-y-4">
              <div className="space-y-1 border-b pb-3">
                <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-emerald-600" />
                  <span>CĂN CỨ PHÁP LÝ & HỆ THỐNG THÔNG TƯ ĐỊNH MỨC BỘ XÂY DỰNG</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Phần mềm Dự toán F1 Pro được lập trình tuân thủ nghiêm ngặt các văn bản quy phạm pháp luật hiện hành
                </p>
              </div>

              <div className="space-y-3 text-xs">
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                  <div className="font-bold text-slate-900 text-xs flex items-center justify-between">
                    <span>1. Nghị định số 10/2021/NĐ-CP của Chính phủ</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-mono">Hiệu lực hiện hành</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed">
                    Về quản lý chi phí đầu tư xây dựng: Quy định phương pháp lập tổng mức đầu tư xây dựng, dự toán xây dựng công trình, dự toán gói thầu, định mức và giá xây dựng công trình.
                  </p>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                  <div className="font-bold text-slate-900 text-xs flex items-center justify-between">
                    <span>2. Thông tư số 12/2021/TT-BXD & Thông tư 14/2023/TT-BXD của Bộ Xây dựng</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-mono">Định mức TT12 & TT14</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed">
                    Ban hành định mức xây dựng: Định mức dự toán xây dựng công trình (phần khảo sát, xây dựng, lắp đặt, sửa chữa, thí nghiệm vật liệu, quản lý dự án và tư vấn đầu tư).
                  </p>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                  <div className="font-bold text-slate-900 text-xs flex items-center justify-between">
                    <span>3. Thông tư số 11/2021/TT-BXD của Bộ Xây dựng</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-purple-100 text-purple-800 font-mono">Xác định chi phí THKP</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed">
                    Hướng dẫn một số nội dung xác định và quản lý chi phí đầu tư xây dựng: Bảng 3.1 định mức chi phí chung, chi phí nhà tạm 1.2% - 2.2%, chi phí không xác định được khối lượng từ thiết kế 2.5% và thu nhập chịu thuế tính trước 5.5%.
                  </p>
                </div>

                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                  <div className="font-bold text-slate-900 text-xs flex items-center justify-between">
                    <span>4. Nghị định số 30/2020/NĐ-CP của Chính phủ</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-red-100 text-red-800 font-mono">Thể thức in ấn</span>
                  </div>
                  <p className="text-slate-600 leading-relaxed">
                    Về công tác văn thư: Quy định chuẩn thể thức và kỹ thuật trình bày văn bản hành chính nhà nước (Quốc hiệu, Tiêu ngữ, Tên cơ quan, Tiêu đề hồ sơ, Khối chữ ký phê duyệt).
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Modal */}
        <div className="px-6 py-3 bg-slate-100 border-t border-slate-200 flex items-center justify-between shrink-0 text-xs">
          <div className="flex items-center gap-2 text-slate-500 text-[11px]">
            <BookOpen className="w-4 h-4 text-blue-600" />
            <span>Hỗ trợ kỹ thuật 24/7: <strong>support@dutoanf1.vn</strong> | Hotline: <strong>1900-6886</strong></span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg font-semibold transition-colors cursor-pointer"
            >
              Đóng hướng dẫn (Esc)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

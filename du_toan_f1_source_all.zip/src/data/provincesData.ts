import { ProvinceData } from '../types/estimate';

/**
 * Danh mục 63 tỉnh thành phố trực thuộc Trung ương Việt Nam
 * Cập nhật phân vùng lương tối thiểu (Vùng I, II, III, IV) và hệ số điều chỉnh chi phí xây dựng
 */
export const PROVINCES_DATA: ProvinceData[] = [
  // 5 Thành phố trực thuộc Trung ương
  { id: 'HN', name: 'Hà Nội', region: 'I', laborCoefficient: 1.0, machineCoefficient: 1.0, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'HCM', name: 'TP. Hồ Chí Minh', region: 'I', laborCoefficient: 1.02, machineCoefficient: 1.01, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'HP', name: 'Hải Phòng', region: 'I', laborCoefficient: 0.98, machineCoefficient: 0.99, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'DN', name: 'Đà Nẵng', region: 'II', laborCoefficient: 0.95, machineCoefficient: 0.97, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'CT', name: 'Cần Thơ', region: 'II', laborCoefficient: 0.93, machineCoefficient: 0.95, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },

  // Miền Bắc (25 tỉnh)
  { id: 'BN', name: 'Bắc Ninh', region: 'I', laborCoefficient: 0.97, machineCoefficient: 0.98, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'BG', name: 'Bắc Giang', region: 'II', laborCoefficient: 0.93, machineCoefficient: 0.95, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'BK', name: 'Bắc Kạn', region: 'III', laborCoefficient: 0.86, machineCoefficient: 0.91, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },
  { id: 'CB', name: 'Cao Bằng', region: 'IV', laborCoefficient: 0.84, machineCoefficient: 0.90, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },
  { id: 'DB', name: 'Điện Biên', region: 'IV', laborCoefficient: 0.84, machineCoefficient: 0.90, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },
  { id: 'HG', name: 'Hà Giang', region: 'IV', laborCoefficient: 0.84, machineCoefficient: 0.90, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },
  { id: 'HNM', name: 'Hà Nam', region: 'II', laborCoefficient: 0.91, machineCoefficient: 0.94, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'HD', name: 'Hải Dương', region: 'I', laborCoefficient: 0.96, machineCoefficient: 0.97, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'HB', name: 'Hòa Bình', region: 'III', laborCoefficient: 0.88, machineCoefficient: 0.92, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },
  { id: 'HY', name: 'Hưng Yên', region: 'I', laborCoefficient: 0.96, machineCoefficient: 0.97, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'LC', name: 'Lai Châu', region: 'IV', laborCoefficient: 0.83, machineCoefficient: 0.89, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },
  { id: 'LS', name: 'Lạng Sơn', region: 'III', laborCoefficient: 0.87, machineCoefficient: 0.92, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },
  { id: 'LCA', name: 'Lào Cai', region: 'II', laborCoefficient: 0.91, machineCoefficient: 0.94, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },
  { id: 'ND', name: 'Nam Định', region: 'II', laborCoefficient: 0.90, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'NB', name: 'Ninh Bình', region: 'II', laborCoefficient: 0.91, machineCoefficient: 0.94, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'PT', name: 'Phú Thọ', region: 'II', laborCoefficient: 0.90, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'QN', name: 'Quảng Ninh', region: 'I', laborCoefficient: 0.97, machineCoefficient: 0.98, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'SL', name: 'Sơn La', region: 'IV', laborCoefficient: 0.84, machineCoefficient: 0.90, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },
  { id: 'TB', name: 'Thái Bình', region: 'II', laborCoefficient: 0.90, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'TN', name: 'Thái Nguyên', region: 'II', laborCoefficient: 0.92, machineCoefficient: 0.95, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'TQ', name: 'Tuyên Quang', region: 'III', laborCoefficient: 0.86, machineCoefficient: 0.91, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },
  { id: 'VP', name: 'Vĩnh Phúc', region: 'I', laborCoefficient: 0.96, machineCoefficient: 0.97, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'YB', name: 'Yên Bái', region: 'III', laborCoefficient: 0.86, machineCoefficient: 0.91, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },

  // Miền Trung & Tây Nguyên (19 tỉnh)
  { id: 'TH', name: 'Thanh Hóa', region: 'II', laborCoefficient: 0.89, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'NA', name: 'Nghệ An', region: 'II', laborCoefficient: 0.89, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'HT', name: 'Hà Tĩnh', region: 'II', laborCoefficient: 0.88, machineCoefficient: 0.92, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'QB', name: 'Quảng Bình', region: 'II', laborCoefficient: 0.88, machineCoefficient: 0.92, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'QT', name: 'Quảng Trị', region: 'III', laborCoefficient: 0.87, machineCoefficient: 0.91, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'TTH', name: 'Thừa Thiên Huế', region: 'II', laborCoefficient: 0.91, machineCoefficient: 0.94, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'QNM', name: 'Quảng Nam', region: 'II', laborCoefficient: 0.90, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'QNG', name: 'Quảng Ngãi', region: 'II', laborCoefficient: 0.89, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'BDH', name: 'Bình Định', region: 'II', laborCoefficient: 0.90, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'PY', name: 'Phú Yên', region: 'III', laborCoefficient: 0.87, machineCoefficient: 0.91, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'KH', name: 'Khánh Hòa', region: 'I', laborCoefficient: 0.95, machineCoefficient: 0.97, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'NT', name: 'Ninh Thuận', region: 'II', laborCoefficient: 0.88, machineCoefficient: 0.92, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'BTH', name: 'Bình Thuận', region: 'II', laborCoefficient: 0.90, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'KT', name: 'Kon Tum', region: 'III', laborCoefficient: 0.85, machineCoefficient: 0.90, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },
  { id: 'GL', name: 'Gia Lai', region: 'III', laborCoefficient: 0.86, machineCoefficient: 0.91, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },
  { id: 'DL', name: 'Đắk Lắk', region: 'II', laborCoefficient: 0.89, machineCoefficient: 0.93, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },
  { id: 'DNO', name: 'Đắk Nông', region: 'III', laborCoefficient: 0.86, machineCoefficient: 0.91, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },
  { id: 'LD', name: 'Lâm Đồng', region: 'II', laborCoefficient: 0.91, machineCoefficient: 0.94, gasolinePrice: 23250, dieselPrice: 20910, electricityPrice: 2006 },

  // Miền Nam & Tây Nam Bộ (19 tỉnh)
  { id: 'BD', name: 'Bình Dương', region: 'I', laborCoefficient: 1.01, machineCoefficient: 1.0, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'DON', name: 'Đồng Nai', region: 'I', laborCoefficient: 1.0, machineCoefficient: 1.0, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'VT', name: 'Bà Rịa - Vũng Tàu', region: 'I', laborCoefficient: 0.99, machineCoefficient: 1.0, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'TNINH', name: 'Tây Ninh', region: 'II', laborCoefficient: 0.92, machineCoefficient: 0.95, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'BP', name: 'Bình Phước', region: 'II', laborCoefficient: 0.90, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'LA', name: 'Long An', region: 'I', laborCoefficient: 0.96, machineCoefficient: 0.97, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'TG', name: 'Tiền Giang', region: 'II', laborCoefficient: 0.91, machineCoefficient: 0.94, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'BTRE', name: 'Bến Tre', region: 'II', laborCoefficient: 0.89, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'TV', name: 'Trà Vinh', region: 'II', laborCoefficient: 0.88, machineCoefficient: 0.92, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'VL', name: 'Vĩnh Long', region: 'II', laborCoefficient: 0.89, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'DT', name: 'Đồng Tháp', region: 'II', laborCoefficient: 0.89, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'AG', name: 'An Giang', region: 'II', laborCoefficient: 0.90, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'KG', name: 'Kiên Giang', region: 'II', laborCoefficient: 0.92, machineCoefficient: 0.95, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'HGIA', name: 'Hậu Giang', region: 'II', laborCoefficient: 0.88, machineCoefficient: 0.92, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'ST', name: 'Sóc Trăng', region: 'II', laborCoefficient: 0.88, machineCoefficient: 0.92, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'BL', name: 'Bạc Liêu', region: 'II', laborCoefficient: 0.88, machineCoefficient: 0.92, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
  { id: 'CM', name: 'Cà Mau', region: 'II', laborCoefficient: 0.89, machineCoefficient: 0.93, gasolinePrice: 22800, dieselPrice: 20500, electricityPrice: 2006 },
];

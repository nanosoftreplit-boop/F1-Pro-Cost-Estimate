import { NormTemplate, ProvinceData } from '../types/estimate';

export { PROVINCES_DATA } from './provincesData';

export const NORMS_CATALOG: NormTemplate[] = [
  {
    code: 'AA.11111',
    name: 'Phát hoang dọn dẹp mặt bằng bằng thủ công',
    unit: '100m2',
    defaultPriceMat: 0,
    defaultPriceLab: 185000,
    defaultPriceMac: 0,
    materials: [],
    labors: [
      { code: 'NC_3.0', name: 'Nhân công bậc 3.0/7', unit: 'công', norm: 0.74, price: 250000, rank: '3.0/7' }
    ],
    machines: []
  },
  {
    code: 'AB.11111',
    name: 'Đào móng băng rộng <= 3m, sâu <= 1m, đất cấp III',
    unit: '100m3',
    defaultPriceMat: 0,
    defaultPriceLab: 28400000,
    defaultPriceMac: 0,
    materials: [],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 98.5, price: 288324, rank: '3.5/7' }
    ],
    machines: []
  },
  {
    code: 'AB.21121',
    name: 'Đào hố móng cột độc lập, sâu <= 1m, đất cấp II',
    unit: 'm3',
    defaultPriceMat: 0,
    defaultPriceLab: 245000,
    defaultPriceMac: 0,
    materials: [],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 0.85, price: 288324, rank: '3.5/7' }
    ],
    machines: []
  },
  {
    code: 'AB.25111',
    name: 'Đào móng bằng máy đào gầu 0.8m3 kết hợp sửa thủ công',
    unit: '100m3',
    defaultPriceMat: 0,
    defaultPriceLab: 2880000,
    defaultPriceMac: 3650000,
    materials: [],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 10.0, price: 288324, rank: '3.5/7' }
    ],
    machines: [
      { code: 'M_MD08', name: 'Máy đào gầu 0.8m3', unit: 'ca', norm: 1.15, price: 3174000 }
    ]
  },
  {
    code: 'AC.11111',
    name: 'Đắp đất nền móng công trình, độ chặt K=0.90 bằng thủ công',
    unit: 'm3',
    defaultPriceMat: 95000,
    defaultPriceLab: 115000,
    defaultPriceMac: 25000,
    materials: [
      { code: 'VL_DAT', name: 'Đất cấp phối đắp nền', unit: 'm3', norm: 1.15, price: 82600, monthlyPrice: 95000 }
    ],
    labors: [
      { code: 'NC_3.0', name: 'Nhân công bậc 3.0/7', unit: 'công', norm: 0.46, price: 250000, rank: '3.0/7' }
    ],
    machines: [
      { code: 'M_DCOC', name: 'Máy đầm cóc 70kg', unit: 'ca', norm: 0.08, price: 312500 }
    ]
  },
  {
    code: 'AF.11111',
    name: 'Bê tông lót móng đá 4x6 mác 100, vữa XM PC30',
    unit: 'm3',
    defaultPriceMat: 785000,
    defaultPriceLab: 260000,
    defaultPriceMac: 38000,
    materials: [
      { code: 'VL_XM30', name: 'Xi măng PC30', unit: 'kg', norm: 198, price: 1650, monthlyPrice: 1750 },
      { code: 'VL_CATV', name: 'Cát vàng', unit: 'm3', norm: 0.52, price: 280000, monthlyPrice: 310000 },
      { code: 'VL_DA46', name: 'Đá 4x6', unit: 'm3', norm: 0.92, price: 240000, monthlyPrice: 260000 },
      { code: 'VL_NUOC', name: 'Nước sinh hoạt', unit: 'lít', norm: 185, price: 25, monthlyPrice: 25 }
    ],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 0.9, price: 288324, rank: '3.5/7' }
    ],
    machines: [
      { code: 'M_TRON', name: 'Máy trộn bê tông 250 lít', unit: 'ca', norm: 0.12, price: 315000 }
    ]
  },
  {
    code: 'AF.12210',
    name: 'Bê tông móng đá 1x2 mác 200, vữa XM PC40',
    unit: 'm3',
    defaultPriceMat: 980000,
    defaultPriceLab: 320000,
    defaultPriceMac: 65000,
    materials: [
      { code: 'VL_XM40', name: 'Xi măng PC40', unit: 'kg', norm: 285, price: 1820, monthlyPrice: 1950 },
      { code: 'VL_CATV', name: 'Cát vàng', unit: 'm3', norm: 0.48, price: 280000, monthlyPrice: 310000 },
      { code: 'VL_DA12', name: 'Đá 1x2', unit: 'm3', norm: 0.88, price: 340000, monthlyPrice: 380000 },
      { code: 'VL_NUOC', name: 'Nước sạch', unit: 'lít', norm: 175, price: 25, monthlyPrice: 25 }
    ],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 1.11, price: 288324, rank: '3.5/7' }
    ],
    machines: [
      { code: 'M_TRON', name: 'Máy trộn bê tông 250 lít', unit: 'ca', norm: 0.14, price: 315000 },
      { code: 'M_DDUI', name: 'Máy đầm dùi 1.5 kW', unit: 'ca', norm: 0.12, price: 175000 }
    ]
  },
  {
    code: 'AF.12320',
    name: 'Bê tông cột tiết diện <= 0.1m2 đá 1x2 mác 250, vữa XM PC40',
    unit: 'm3',
    defaultPriceMat: 1120000,
    defaultPriceLab: 480000,
    defaultPriceMac: 85000,
    materials: [
      { code: 'VL_XM40', name: 'Xi măng PC40', unit: 'kg', norm: 325, price: 1820, monthlyPrice: 1950 },
      { code: 'VL_CATV', name: 'Cát vàng', unit: 'm3', norm: 0.47, price: 280000, monthlyPrice: 310000 },
      { code: 'VL_DA12', name: 'Đá 1x2', unit: 'm3', norm: 0.86, price: 340000, monthlyPrice: 380000 },
      { code: 'VL_NUOC', name: 'Nước sạch', unit: 'lít', norm: 175, price: 25, monthlyPrice: 25 }
    ],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 1.66, price: 288324, rank: '3.5/7' }
    ],
    machines: [
      { code: 'M_TRON', name: 'Máy trộn bê tông 250 lít', unit: 'ca', norm: 0.16, price: 315000 },
      { code: 'M_DDUI', name: 'Máy đầm dùi 1.5 kW', unit: 'ca', norm: 0.18, price: 175000 }
    ]
  },
  {
    code: 'AF.12420',
    name: 'Bê tông dầm, sàn đá 1x2 mác 250, vữa XM PC40',
    unit: 'm3',
    defaultPriceMat: 1095000,
    defaultPriceLab: 410000,
    defaultPriceMac: 75000,
    materials: [
      { code: 'VL_XM40', name: 'Xi măng PC40', unit: 'kg', norm: 325, price: 1820, monthlyPrice: 1950 },
      { code: 'VL_CATV', name: 'Cát vàng', unit: 'm3', norm: 0.47, price: 280000, monthlyPrice: 310000 },
      { code: 'VL_DA12', name: 'Đá 1x2', unit: 'm3', norm: 0.86, price: 340000, monthlyPrice: 380000 },
      { code: 'VL_NUOC', name: 'Nước sạch', unit: 'lít', norm: 175, price: 25, monthlyPrice: 25 }
    ],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 1.42, price: 288324, rank: '3.5/7' }
    ],
    machines: [
      { code: 'M_TRON', name: 'Máy trộn bê tông 250 lít', unit: 'ca', norm: 0.15, price: 315000 },
      { code: 'M_DBAN', name: 'Máy đầm bàn 1.0 kW', unit: 'ca', norm: 0.14, price: 165000 }
    ]
  },
  {
    code: 'AF.61110',
    name: 'Sản xuất, lắp dựng cốt thép móng đường kính <= 10mm',
    unit: 'tấn',
    defaultPriceMat: 17650000,
    defaultPriceLab: 3200000,
    defaultPriceMac: 420000,
    materials: [
      { code: 'VL_THEP10', name: 'Thép thanh vằn D<=10mm', unit: 'tấn', norm: 1.025, price: 16800000, monthlyPrice: 17200000 },
      { code: 'VL_DAYBUOC', name: 'Dây thép buộc 1 ly', unit: 'kg', norm: 15.0, price: 22000, monthlyPrice: 24000 },
      { code: 'VL_QUEHAN', name: 'Que hàn điện', unit: 'kg', norm: 6.5, price: 35000, monthlyPrice: 37000 }
    ],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 11.1, price: 288324, rank: '3.5/7' }
    ],
    machines: [
      { code: 'M_HAN', name: 'Máy hàn điện xoay chiều', unit: 'ca', norm: 0.65, price: 280000 },
      { code: 'M_UONTHEP', name: 'Máy cắt uốn thép 5kW', unit: 'ca', norm: 0.85, price: 280000 }
    ]
  },
  {
    code: 'AF.61120',
    name: 'Sản xuất, lắp dựng cốt thép móng đường kính <= 18mm',
    unit: 'tấn',
    defaultPriceMat: 17400000,
    defaultPriceLab: 2950000,
    defaultPriceMac: 390000,
    materials: [
      { code: 'VL_THEP18', name: 'Thép thanh vằn D<=18mm', unit: 'tấn', norm: 1.02, price: 16600000, monthlyPrice: 17000000 },
      { code: 'VL_DAYBUOC', name: 'Dây thép buộc 1 ly', unit: 'kg', norm: 14.0, price: 22000, monthlyPrice: 24000 },
      { code: 'VL_QUEHAN', name: 'Que hàn điện', unit: 'kg', norm: 7.0, price: 35000, monthlyPrice: 37000 }
    ],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 10.2, price: 288324, rank: '3.5/7' }
    ],
    machines: [
      { code: 'M_HAN', name: 'Máy hàn điện xoay chiều', unit: 'ca', norm: 0.62, price: 280000 },
      { code: 'M_UONTHEP', name: 'Máy cắt uốn thép 5kW', unit: 'ca', norm: 0.77, price: 280000 }
    ]
  },
  {
    code: 'AF.81110',
    name: 'Ván khuôn móng cột, móng băng gỗ phủ phim',
    unit: '100m2',
    defaultPriceMat: 8900000,
    defaultPriceLab: 7400000,
    defaultPriceMac: 250000,
    materials: [
      { code: 'VL_VKPHIM', name: 'Ván ép phủ phim 15mm', unit: 'm2', norm: 125, price: 58000, monthlyPrice: 62000 },
      { code: 'VL_GOHOP', name: 'Gỗ xà gồ hộp 5x10cm', unit: 'm3', norm: 0.45, price: 3400000, monthlyPrice: 3600000 },
      { code: 'VL_DINH', name: 'Đinh đỉa, bu lông liên kết', unit: 'kg', norm: 32.0, price: 26000, monthlyPrice: 28000 }
    ],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 25.6, price: 288324, rank: '3.5/7' }
    ],
    machines: [
      { code: 'M_CUA', name: 'Máy cưa gỗ cầm tay', unit: 'ca', norm: 1.25, price: 200000 }
    ]
  },
  {
    code: 'AF.81210',
    name: 'Ván khuôn cột, dầm sàn gỗ phủ phim, giáo chống thép',
    unit: '100m2',
    defaultPriceMat: 12500000,
    defaultPriceLab: 9800000,
    defaultPriceMac: 350000,
    materials: [
      { code: 'VL_VKPHIM', name: 'Ván ép phủ phim 18mm', unit: 'm2', norm: 135, price: 68000, monthlyPrice: 72000 },
      { code: 'VL_GOHOP', name: 'Gỗ hộp xà gồ', unit: 'm3', norm: 0.65, price: 3400000, monthlyPrice: 3600000 },
      { code: 'VL_GIAO', name: 'Giáo chống thép đĩa/nêm', unit: 'bộ', norm: 45, price: 35000, monthlyPrice: 38000 }
    ],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 34.0, price: 288324, rank: '3.5/7' }
    ],
    machines: [
      { code: 'M_TOI', name: 'Tời nâng vật liệu 1 tấn', unit: 'ca', norm: 0.85, price: 410000 }
    ]
  },
  {
    code: 'BB.11111',
    name: 'Xây tường gạch ống 8x8x19 dày 10cm, vữa XM mác 75',
    unit: 'm3',
    defaultPriceMat: 1150000,
    defaultPriceLab: 520000,
    defaultPriceMac: 25000,
    materials: [
      { code: 'VL_GACHONG', name: 'Gạch tuynel 8x8x19', unit: 'viên', norm: 680, price: 1200, monthlyPrice: 1350 },
      { code: 'VL_XM30', name: 'Xi măng PC30', unit: 'kg', norm: 65, price: 1650, monthlyPrice: 1750 },
      { code: 'VL_CATV', name: 'Cát xây tô', unit: 'm3', norm: 0.28, price: 260000, monthlyPrice: 290000 },
      { code: 'VL_NUOC', name: 'Nước xây', unit: 'lít', norm: 85, price: 25, monthlyPrice: 25 }
    ],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 1.8, price: 288324, rank: '3.5/7' }
    ],
    machines: [
      { code: 'M_TRON', name: 'Máy trộn vữa 150 lít', unit: 'ca', norm: 0.1, price: 250000 }
    ]
  },
  {
    code: 'BB.11211',
    name: 'Xây tường gạch ống 8x8x19 dày 20cm, vữa XM mác 75',
    unit: 'm3',
    defaultPriceMat: 1080000,
    defaultPriceLab: 460000,
    defaultPriceMac: 25000,
    materials: [
      { code: 'VL_GACHONG', name: 'Gạch tuynel 8x8x19', unit: 'viên', norm: 650, price: 1200, monthlyPrice: 1350 },
      { code: 'VL_XM30', name: 'Xi măng PC30', unit: 'kg', norm: 62, price: 1650, monthlyPrice: 1750 },
      { code: 'VL_CATV', name: 'Cát xây tô', unit: 'm3', norm: 0.26, price: 260000, monthlyPrice: 290000 },
      { code: 'VL_NUOC', name: 'Nước xây', unit: 'lít', norm: 80, price: 25, monthlyPrice: 25 }
    ],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 1.6, price: 288324, rank: '3.5/7' }
    ],
    machines: [
      { code: 'M_TRON', name: 'Máy trộn vữa 150 lít', unit: 'ca', norm: 0.1, price: 250000 }
    ]
  },
  {
    code: 'AK.51110',
    name: 'Trát tường trong nhà dày 1.5cm vữa XM mác 75',
    unit: 'm2',
    defaultPriceMat: 42000,
    defaultPriceLab: 68000,
    defaultPriceMac: 3500,
    materials: [
      { code: 'VL_XM30', name: 'Xi măng PC30', unit: 'kg', norm: 5.8, price: 1650, monthlyPrice: 1750 },
      { code: 'VL_CATM', name: 'Cát mịn trát', unit: 'm3', norm: 0.022, price: 270000, monthlyPrice: 300000 },
      { code: 'VL_NUOC', name: 'Nước', unit: 'lít', norm: 6.5, price: 25, monthlyPrice: 25 }
    ],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 0.235, price: 288324, rank: '3.5/7' }
    ],
    machines: [
      { code: 'M_TRON', name: 'Máy trộn vữa 150 lít', unit: 'ca', norm: 0.014, price: 250000 }
    ]
  },
  {
    code: 'AK.81110',
    name: 'Lát nền gạch ceramic 600x600 vữa xi măng mác 75',
    unit: 'm2',
    defaultPriceMat: 185000,
    defaultPriceLab: 75000,
    defaultPriceMac: 3500,
    materials: [
      { code: 'VL_GACH60', name: 'Gạch granite/ceramic 600x600', unit: 'm2', norm: 1.05, price: 145000, monthlyPrice: 165000 },
      { code: 'VL_KEO', name: 'Keo dán gạch chà ron', unit: 'kg', norm: 1.5, price: 12000, monthlyPrice: 13500 },
      { code: 'VL_XM30', name: 'Xi măng PC30 lót nền', unit: 'kg', norm: 6.2, price: 1650, monthlyPrice: 1750 }
    ],
    labors: [
      { code: 'NC_4.0', name: 'Nhân công bậc 4.0/7', unit: 'công', norm: 0.245, price: 305000, rank: '4.0/7' }
    ],
    machines: [
      { code: 'M_CATGACH', name: 'Máy cắt gạch bàn', unit: 'ca', norm: 0.015, price: 220000 }
    ]
  },
  {
    code: 'AK.91110',
    name: 'Sơn tường trong nhà 1 nước lót 2 nước phủ Maxilite',
    unit: 'm2',
    defaultPriceMat: 38000,
    defaultPriceLab: 32000,
    defaultPriceMac: 0,
    materials: [
      { code: 'VL_BOTBA', name: 'Bột bả tường trong nhà', unit: 'kg', norm: 0.95, price: 9000, monthlyPrice: 10500 },
      { code: 'VL_SONLOT', name: 'Sơn lót kháng kiềm', unit: 'kg', norm: 0.12, price: 58000, monthlyPrice: 62000 },
      { code: 'VL_SONPHU', name: 'Sơn phủ nội thất Maxilite', unit: 'kg', norm: 0.22, price: 65000, monthlyPrice: 70000 },
      { code: 'VL_GIAYNHAM', name: 'Giấy ráp mịn', unit: 'tờ', norm: 0.5, price: 3500, monthlyPrice: 4000 }
    ],
    labors: [
      { code: 'NC_3.5', name: 'Nhân công bậc 3.5/7', unit: 'công', norm: 0.11, price: 288324, rank: '3.5/7' }
    ],
    machines: []
  },
  {
    code: 'AL.11110',
    name: 'Lắp đặt ống cấp nước nóng lạnh PPR D25 đi chìm tường',
    unit: 'm',
    defaultPriceMat: 45000,
    defaultPriceLab: 38000,
    defaultPriceMac: 2500,
    materials: [
      { code: 'VL_ONGPPR', name: 'Ống hàn nhiệt PPR D25', unit: 'm', norm: 1.05, price: 32000, monthlyPrice: 35000 },
      { code: 'VL_PHUKIEN', name: 'Phụ kiện tê, co cút D25', unit: 'cái', norm: 1.2, price: 8500, monthlyPrice: 9500 }
    ],
    labors: [
      { code: 'NC_4.0', name: 'Thợ điện nước bậc 4.0/7', unit: 'công', norm: 0.124, price: 305000, rank: '4.0/7' }
    ],
    machines: [
      { code: 'M_HANNHIET', name: 'Máy hàn nhiệt PPR', unit: 'ca', norm: 0.01, price: 250000 }
    ]
  },
  {
    code: 'AL.21110',
    name: 'Kéo rải dây điện đôi Cu/PVC 2x2.5mm2 luồn ống gen',
    unit: '100m',
    defaultPriceMat: 1850000,
    defaultPriceLab: 780000,
    defaultPriceMac: 0,
    materials: [
      { code: 'VL_DAYDIEN', name: 'Dây điện Cadivi 2x2.5mm2', unit: 'm', norm: 105, price: 14500, monthlyPrice: 15500 },
      { code: 'VL_ONGGEN', name: 'Ống gen luồn dây chống cháy D20', unit: 'm', norm: 102, price: 3200, monthlyPrice: 3500 }
    ],
    labors: [
      { code: 'NC_4.0', name: 'Thợ điện bậc 4.0/7', unit: 'công', norm: 2.55, price: 305000, rank: '4.0/7' }
    ],
    machines: []
  }
];

// Helper để tìm kiếm nhanh mã hiệu hoặc tên có dấu / không dấu
export function searchNorms(query: string): NormTemplate[] {
  if (!query || query.trim() === '') return NORMS_CATALOG;
  const qClean = removeVietnameseTones(query.toLowerCase().trim());
  return NORMS_CATALOG.filter(norm => {
    const codeMatch = norm.code.toLowerCase().includes(query.toLowerCase().trim());
    const nameClean = removeVietnameseTones(norm.name.toLowerCase());
    return codeMatch || nameClean.includes(qClean);
  });
}

export function removeVietnameseTones(str: string): string {
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D');
}

import React, { useState } from 'react';
import { ProjectSettings } from '../types/estimate';
import { PROVINCES_DATA } from '../data/normsData';
import { formatVND } from '../utils/calculator';
import { Coins, Check, X, ShieldAlert } from 'lucide-react';

interface MonthlyPriceCatalogItem {
  code: string;
  name: string;
  unit: string;
  basePrice: number;
  noticePrice: number;
  source: string;
}

interface PriceMonthlyModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: ProjectSettings;
  onApplyMonthlyPrices: (prices: Record<string, number>) => void;
}

export const PriceMonthlyModal: React.FC<PriceMonthlyModalProps> = ({
  isOpen,
  onClose,
  settings,
  onApplyMonthlyPrices,
}) => {
  const [selectedQuarter, setSelectedQuarter] = useState<string>('Q1_2026');
  
  if (!isOpen) return null;

  // Bảng thông báo giá vật liệu xây dựng thực tế theo Sở Xây dựng địa phương
  const NOTICE_PRICES: MonthlyPriceCatalogItem[] = [
    { code: 'VL_XM40', name: 'Xi măng Vicem Hoàng Thạch PCB40', unit: 'kg', basePrice: 1820, noticePrice: 1950, source: `Công bố giá Sở XD ${settings.locationProvince}` },
    { code: 'VL_XM30', name: 'Xi măng Bút Sơn PCB30', unit: 'kg', basePrice: 1650, noticePrice: 1750, source: `Công bố giá Sở XD ${settings.locationProvince}` },
    { code: 'VL_CATV', name: 'Cát vàng hạt trung (mỏ Sông Lô / Sông Hồng)', unit: 'm3', basePrice: 280000, noticePrice: 320000, source: 'Giá thị trường mỏ cát' },
    { code: 'VL_CATM', name: 'Cát mịn trát tường', unit: 'm3', basePrice: 270000, noticePrice: 300000, source: 'Báo giá liên sở' },
    { code: 'VL_DA12', name: 'Đá 1x2 mỏ Hà Nam / Bình Dương', unit: 'm3', basePrice: 340000, noticePrice: 385000, source: 'Công bố giá mỏ đá' },
    { code: 'VL_DA46', name: 'Đá 4x6 lót móng', unit: 'm3', basePrice: 240000, noticePrice: 265000, source: 'Công bố giá mỏ đá' },
    { code: 'VL_THEP10', name: 'Thép Hòa Phát D<=10mm CB300V', unit: 'tấn', basePrice: 16800000, noticePrice: 17250000, source: 'Báo giá Nhà máy Hòa Phát' },
    { code: 'VL_THEP18', name: 'Thép Hòa Phát D<=18mm CB400V', unit: 'tấn', basePrice: 16600000, noticePrice: 17050000, source: 'Báo giá Nhà máy Hòa Phát' },
    { code: 'VL_GACHONG', name: 'Gạch tuynel 8x8x19 loại A', unit: 'viên', basePrice: 1200, noticePrice: 1380, source: 'Công bố giá VLXD liên sở' },
    { code: 'VL_VKPHIM', name: 'Ván ép phủ phim 18mm phủ keo phenolic', unit: 'm2', basePrice: 68000, noticePrice: 72000, source: 'Báo giá tổng kho ván ép' },
    { code: 'VL_GACH60', name: 'Gạch granite Đồng Tâm 600x600', unit: 'm2', basePrice: 145000, noticePrice: 165000, source: 'Showroom Đồng Tâm' },
    { code: 'VL_SONPHU', name: 'Sơn nội thất cao cấp Maxilite / Dulux', unit: 'kg', basePrice: 65000, noticePrice: 70000, source: 'Đại lý sơn cấp 1' },
    { code: 'VL_DAYDIEN', name: 'Dây điện đôi Cadivi 2x2.5mm2', unit: 'm', basePrice: 14500, noticePrice: 15800, source: 'Bảng giá Cadivi niêm yết' },
    { code: 'VL_ONGPPR', name: 'Ống nước nóng PPR Tiền Phong D25', unit: 'm', basePrice: 32000, noticePrice: 35000, source: 'Nhựa Tiền Phong' },
  ];

  const handleApply = () => {
    const patchMap: Record<string, number> = {};
    NOTICE_PRICES.forEach(item => {
      patchMap[item.code] = item.noticePrice;
    });
    onApplyMonthlyPrices(patchMap);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4">
      <div className="bg-white rounded-lg shadow-2xl border border-slate-300 w-full max-w-3xl flex flex-col text-xs text-slate-800 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <Coins className="w-4 h-4 text-amber-400" />
            <h3 className="font-bold text-sm tracking-tight">
              LẮP GIÁ THÔNG BÁO VẬT LIỆU XÂY DỰNG - SỞ XÂY DỰNG {settings.locationProvince.toUpperCase()}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Filter bar */}
        <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-medium text-slate-700">Kỳ thông báo:</span>
            <select
              value={selectedQuarter}
              onChange={(e) => setSelectedQuarter(e.target.value)}
              className="px-2 py-1 border border-slate-300 rounded bg-white text-xs font-semibold"
            >
              <option value="Q1_2026">Quý 1/2026 (Mới nhất - Công bố số 42/CBG-SXD)</option>
              <option value="Q4_2025">Quý 4/2025 (Công bố số 118/CBG-SXD)</option>
              <option value="Q3_2025">Quý 3/2025 (Công bố số 89/CBG-SXD)</option>
            </select>
          </div>
          <span className="text-[11px] text-slate-500">
            Khu vực: <strong>{settings.locationProvince} (Vùng {settings.salaryRegion})</strong>
          </span>
        </div>

        {/* Notice Price Table */}
        <div className="p-3 max-h-[50vh] overflow-y-auto">
          <table className="w-full border-collapse border border-slate-300 table-auto select-text">
            <thead className="bg-slate-100 border-b border-slate-300">
              <tr>
                <th className="f1-header-cell w-20">Mã VT</th>
                <th className="f1-header-cell text-left px-3">Tên vật liệu</th>
                <th className="f1-header-cell w-14">ĐVT</th>
                <th className="f1-header-cell w-24">Giá gốc</th>
                <th className="f1-header-cell w-28 bg-amber-100 font-bold text-amber-900">Giá thông báo</th>
                <th className="f1-header-cell w-24">Chênh lệch</th>
                <th className="f1-header-cell min-w-[160px] text-left px-2">Nguồn công bố</th>
              </tr>
            </thead>
            <tbody>
              {NOTICE_PRICES.map((item) => {
                const diff = item.noticePrice - item.basePrice;
                return (
                  <tr key={item.code} className="hover:bg-slate-50 border-b border-slate-200">
                    <td className="f1-cell text-center font-mono text-slate-500">{item.code}</td>
                    <td className="f1-cell px-3 font-medium text-slate-800">{item.name}</td>
                    <td className="f1-cell text-center text-slate-600">{item.unit}</td>
                    <td className="f1-cell text-right tabular-nums text-slate-600 font-mono">{formatVND(item.basePrice)}</td>
                    <td className="f1-cell text-right tabular-nums font-bold text-amber-900 bg-amber-50/50 font-mono">
                      {formatVND(item.noticePrice)}
                    </td>
                    <td className={`f1-cell text-right tabular-nums font-mono font-medium ${diff > 0 ? 'text-amber-700' : 'text-slate-500'}`}>
                      {diff > 0 ? `+${formatVND(diff)}` : formatVND(diff)}
                    </td>
                    <td className="f1-cell px-2 text-slate-500 text-[10px] italic">{item.source}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Footer actions */}
        <div className="p-3 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
          <span className="text-[11px] text-slate-600">
            Tự động cập nhật vào bảng Giá tháng (THVT) và tính lại toàn bộ dự toán
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded font-medium transition-colors"
            >
              Hủy
            </button>
            <button
              onClick={handleApply}
              className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded font-bold transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Check className="w-3.5 h-3.5" />
              <span>ÁP DỤNG TOÀN BỘ GIÁ THÁNG</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

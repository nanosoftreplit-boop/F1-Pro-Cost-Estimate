import React, { useState } from 'react';
import { WorkItem, Category, SubCalculation } from '../types/estimate';
import { evaluateMathExpression, formatQuantity, formatVND } from '../utils/calculator';
import { Plus, Trash2, ChevronDown, ChevronRight, Edit3, Search } from 'lucide-react';

interface CongTrinhSheetProps {
  items: WorkItem[];
  categories: Category[];
  selectedItemId: string | null;
  selectedSubCalcId: string | null;
  onSelectItem: (item: WorkItem, subCalc?: SubCalculation) => void;
  onUpdateWorkItem: (itemId: string, patch: Partial<WorkItem>) => void;
  onDeleteWorkItem: (itemId: string) => void;
  onAddSubCalculation: (itemId: string) => void;
  onUpdateSubCalculation: (itemId: string, subId: string, patch: Partial<SubCalculation>) => void;
  onDeleteSubCalculation: (itemId: string, subId: string) => void;
  onOpenNormLookupForWorkItem: (itemId: string) => void;
  onAddCategory: () => void;
}

export const CongTrinhSheet: React.FC<CongTrinhSheetProps> = ({
  items,
  categories,
  selectedItemId,
  selectedSubCalcId,
  onSelectItem,
  onUpdateWorkItem,
  onDeleteWorkItem,
  onAddSubCalculation,
  onUpdateSubCalculation,
  onDeleteSubCalculation,
  onOpenNormLookupForWorkItem,
}) => {
  const [collapsedCategories, setCollapsedCategories] = useState<Record<string, boolean>>({});

  const toggleCategory = (catId: string) => {
    setCollapsedCategories(prev => ({ ...prev, [catId]: !prev[catId] }));
  };

  // Tính tổng toàn bộ công trình
  let totalMaterial = 0;
  let totalLabor = 0;
  let totalMachine = 0;

  items.forEach(item => {
    const q = item.quantity || 0;
    totalMaterial += q * (item.unitPriceMaterial || 0);
    totalLabor += q * (item.unitPriceLabor || 0);
    totalMachine += q * (item.unitPriceMachine || 0);
  });
  const grandTotal = totalMaterial + totalLabor + totalMachine;

  return (
    <div className="flex-1 flex flex-col h-full bg-white overflow-hidden text-xs">
      <div className="flex-1 overflow-auto">
        <table className="w-full border-collapse border border-slate-300 table-auto select-text">
          <thead className="sticky top-0 z-10 bg-slate-100 shadow-xs">
            <tr className="border-b border-slate-300">
              <th rowSpan={2} className="f1-header-cell w-10">STT</th>
              <th rowSpan={2} className="f1-header-cell w-24">Mã hiệu</th>
              <th rowSpan={2} className="f1-header-cell min-w-[260px] text-left px-3">Tên công tác & quy cách</th>
              <th rowSpan={2} className="f1-header-cell w-16">Đơn vị</th>
              <th rowSpan={2} className="f1-header-cell w-24">Khối lượng</th>
              <th colSpan={3} className="f1-header-cell">Đơn giá gốc (VNĐ)</th>
              <th colSpan={4} className="f1-header-cell">Thành tiền (VNĐ)</th>
              <th rowSpan={2} className="f1-header-cell w-16">Thao tác</th>
            </tr>
            <tr className="border-b border-slate-300 bg-slate-50">
              <th className="f1-header-cell w-24">Vật liệu</th>
              <th className="f1-header-cell w-24">Nhân công</th>
              <th className="f1-header-cell w-24">Máy</th>
              <th className="f1-header-cell w-28">Vật liệu</th>
              <th className="f1-header-cell w-28">Nhân công</th>
              <th className="f1-header-cell w-28">Máy</th>
              <th className="f1-header-cell w-32 bg-slate-200 font-bold">Tổng cộng</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((cat, catIdx) => {
              const catItems = items.filter(item => item.categoryId === cat.id);
              const isCollapsed = collapsedCategories[cat.id];

              let catMat = 0;
              let catLab = 0;
              let catMac = 0;
              catItems.forEach(i => {
                const q = i.quantity || 0;
                catMat += q * i.unitPriceMaterial;
                catLab += q * i.unitPriceLabor;
                catMac += q * i.unitPriceMachine;
              });
              const catTotal = catMat + catLab + catMac;

              return (
                <React.Fragment key={cat.id}>
                  {/* Category Header Row */}
                  <tr className="bg-slate-200/90 font-bold text-slate-800 border-y border-slate-300">
                    <td className="f1-cell text-center">{catIdx + 1}</td>
                    <td className="f1-cell text-center text-slate-600 font-mono text-[11px]">HM.{catIdx + 1}</td>
                    <td colSpan={6} className="f1-cell px-3">
                      <button
                        onClick={() => toggleCategory(cat.id)}
                        className="flex items-center gap-1.5 hover:text-blue-700 text-left font-bold"
                      >
                        {isCollapsed ? <ChevronRight className="w-3.5 h-3.5 text-slate-500" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-500" />}
                        <span>{cat.name.toUpperCase()}</span>
                      </button>
                    </td>
                    <td className="f1-cell text-right tabular-nums">{formatVND(catMat)}</td>
                    <td className="f1-cell text-right tabular-nums">{formatVND(catLab)}</td>
                    <td className="f1-cell text-right tabular-nums">{formatVND(catMac)}</td>
                    <td className="f1-cell text-right tabular-nums font-bold text-slate-900 bg-slate-300/50">
                      {formatVND(catTotal)}
                    </td>
                    <td className="f1-cell text-center"></td>
                  </tr>

                  {/* Work Items in this Category */}
                  {!isCollapsed &&
                    catItems.map((item) => {
                      const isSelected = selectedItemId === item.id && !selectedSubCalcId;
                      const q = item.quantity || 0;
                      const tMat = q * item.unitPriceMaterial;
                      const tLab = q * item.unitPriceLabor;
                      const tMac = q * item.unitPriceMachine;
                      const tTotal = tMat + tLab + tMac;

                      return (
                        <React.Fragment key={item.id}>
                          <tr
                            onClick={() => onSelectItem(item)}
                            className={`cursor-pointer transition-colors ${
                              isSelected ? 'bg-blue-50/80 ring-1 ring-blue-400' : 'hover:bg-slate-50/90'
                            }`}
                          >
                            <td className="f1-cell text-center text-slate-500 font-mono">{item.stt}</td>
                            <td className="f1-cell text-center font-mono font-medium text-blue-700">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onOpenNormLookupForWorkItem(item.id);
                                }}
                                className="hover:underline flex items-center justify-center gap-1 mx-auto"
                                title="Nhấn để tra cứu và thay đổi định mức"
                              >
                                <span>{item.code}</span>
                                <Search className="w-2.5 h-2.5 text-slate-400" />
                              </button>
                            </td>
                            <td className="f1-cell px-3">
                              <input
                                type="text"
                                value={item.name}
                                onChange={(e) => onUpdateWorkItem(item.id, { name: e.target.value })}
                                className="w-full bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded text-slate-900 font-medium"
                              />
                            </td>
                            <td className="f1-cell text-center text-slate-600">
                              <input
                                type="text"
                                value={item.unit}
                                onChange={(e) => onUpdateWorkItem(item.id, { unit: e.target.value })}
                                className="w-full text-center bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded text-slate-700 font-mono text-[11px]"
                              />
                            </td>
                            <td className="f1-cell text-right tabular-nums font-semibold text-slate-900 bg-amber-50/30">
                              <input
                                type="number"
                                step="any"
                                value={item.quantity}
                                onChange={(e) => onUpdateWorkItem(item.id, { quantity: parseFloat(e.target.value) || 0 })}
                                className="w-full text-right bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded font-mono"
                              />
                            </td>
                            <td className="f1-cell text-right tabular-nums text-slate-700">
                              <input
                                type="number"
                                value={item.unitPriceMaterial}
                                onChange={(e) => onUpdateWorkItem(item.id, { unitPriceMaterial: parseFloat(e.target.value) || 0 })}
                                className="w-full text-right bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded font-mono"
                              />
                            </td>
                            <td className="f1-cell text-right tabular-nums text-slate-700">
                              <input
                                type="number"
                                value={item.unitPriceLabor}
                                onChange={(e) => onUpdateWorkItem(item.id, { unitPriceLabor: parseFloat(e.target.value) || 0 })}
                                className="w-full text-right bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded font-mono"
                              />
                            </td>
                            <td className="f1-cell text-right tabular-nums text-slate-700">
                              <input
                                type="number"
                                value={item.unitPriceMachine}
                                onChange={(e) => onUpdateWorkItem(item.id, { unitPriceMachine: parseFloat(e.target.value) || 0 })}
                                className="w-full text-right bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded font-mono"
                              />
                            </td>
                            <td className="f1-cell text-right tabular-nums text-slate-800">{formatVND(tMat)}</td>
                            <td className="f1-cell text-right tabular-nums text-slate-800">{formatVND(tLab)}</td>
                            <td className="f1-cell text-right tabular-nums text-slate-800">{formatVND(tMac)}</td>
                            <td className="f1-cell text-right tabular-nums font-bold text-slate-900 bg-slate-100">
                              {formatVND(tTotal)}
                            </td>
                            <td className="f1-cell text-center">
                              <div className="flex items-center justify-center gap-1">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onAddSubCalculation(item.id);
                                  }}
                                  title="Chèn dòng diễn giải kích thước"
                                  className="p-1 text-slate-400 hover:text-amber-600 rounded"
                                >
                                  <Plus className="w-3 h-3" />
                                </button>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onDeleteWorkItem(item.id);
                                  }}
                                  title="Xóa công tác"
                                  className="p-1 text-slate-400 hover:text-red-600 rounded"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            </td>
                          </tr>

                          {/* Sub-calculations / Diễn giải con */}
                          {item.subCalculations && item.subCalculations.map((sub, sIdx) => {
                            const isSubSelected = selectedSubCalcId === sub.id;
                            return (
                              <tr
                                key={sub.id}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onSelectItem(item, sub);
                                }}
                                className={`text-[11px] cursor-pointer ${
                                  isSubSelected ? 'bg-amber-100/70 ring-1 ring-amber-400' : 'bg-slate-50/50 hover:bg-amber-50/40'
                                }`}
                              >
                                <td className="f1-cell text-center text-slate-300 font-mono">{`${item.stt}.${sIdx + 1}`}</td>
                                <td className="f1-cell text-center text-slate-400 font-mono text-[10px]">DG</td>
                                <td className="f1-cell pl-8 pr-3 text-slate-700">
                                  <div className="flex items-center gap-2">
                                    <span className="text-slate-400 select-none">-</span>
                                    <input
                                      type="text"
                                      value={sub.name}
                                      onChange={(e) => onUpdateSubCalculation(item.id, sub.id, { name: e.target.value })}
                                      className="flex-1 bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded text-slate-700 italic"
                                    />
                                    <span className="text-slate-400">:</span>
                                    <input
                                      type="text"
                                      value={sub.expression}
                                      onChange={(e) => {
                                        const expr = e.target.value;
                                        const qty = evaluateMathExpression(expr);
                                        onUpdateSubCalculation(item.id, sub.id, { expression: expr, quantity: qty });
                                      }}
                                      className="w-48 font-mono bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded text-blue-800"
                                    />
                                  </div>
                                </td>
                                <td className="f1-cell text-center text-slate-400">{item.unit}</td>
                                <td className="f1-cell text-right tabular-nums text-slate-700 font-mono font-medium">
                                  {formatQuantity(sub.quantity)}
                                </td>
                                <td colSpan={7} className="f1-cell text-slate-300 bg-slate-50/20"></td>
                                <td className="f1-cell text-center">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      onDeleteSubCalculation(item.id, sub.id);
                                    }}
                                    title="Xóa dòng diễn giải"
                                    className="p-1 text-slate-400 hover:text-red-500 rounded"
                                  >
                                    <Trash2 className="w-2.5 h-2.5" />
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </React.Fragment>
                      );
                    })}
                </React.Fragment>
              );
            })}
          </tbody>
          <tfoot className="sticky bottom-0 z-10 bg-slate-900 text-white font-bold text-xs shadow-md">
            <tr className="border-t-2 border-slate-700">
              <td colSpan={4} className="f1-cell text-center py-2 text-slate-300">
                TỔNG CỘNG TOÀN BỘ CÔNG TRÌNH (TRƯỚC THUẾ)
              </td>
              <td className="f1-cell text-center text-slate-400 font-mono">{items.length} công tác</td>
              <td colSpan={3} className="f1-cell text-slate-500"></td>
              <td className="f1-cell text-right tabular-nums text-slate-200">{formatVND(totalMaterial)}</td>
              <td className="f1-cell text-right tabular-nums text-slate-200">{formatVND(totalLabor)}</td>
              <td className="f1-cell text-right tabular-nums text-slate-200">{formatVND(totalMachine)}</td>
              <td className="f1-cell text-right tabular-nums text-emerald-400 font-bold bg-slate-800 text-sm">
                {formatVND(grandTotal)}
              </td>
              <td className="f1-cell text-center"></td>
            </tr>
          </tfoot>
        </table>
      </div>

      {/* Sheet bottom helper banner */}
      <div className="flex items-center justify-between px-3 py-1 bg-slate-100 border-t border-slate-300 text-[11px] text-slate-600">
        <div className="flex items-center gap-3">
          <span>Nhấn <strong>Tra định mức (F2)</strong> để chọn từ thư viện TT 12</span>
          <span>·</span>
          <span>Chèn dòng diễn giải để tính kích thước dài x rộng x cao</span>
          <span>·</span>
          <span>Thay đổi khối lượng được cập nhật tức thì sang các bảng khác</span>
        </div>
        <div className="font-mono text-slate-700">
          Tổng chi phí xây dựng trực tiếp: <strong className="text-slate-900">{formatVND(grandTotal)} VNĐ</strong>
        </div>
      </div>
    </div>
  );
};

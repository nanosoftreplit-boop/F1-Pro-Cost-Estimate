import React, { useState } from 'react';
import { NormTemplate } from '../types/estimate';
import { NORMS_CATALOG, searchNorms } from '../data/normsData';
import { formatVND } from '../utils/calculator';
import { Search, Plus, Check, Layers, X } from 'lucide-react';

interface NormLookupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectNorm: (norm: NormTemplate) => void;
}

export const NormLookupModal: React.FC<NormLookupModalProps> = ({
  isOpen,
  onClose,
  onSelectNorm,
}) => {
  const [query, setQuery] = useState('');
  const [selectedPreviewNorm, setSelectedPreviewNorm] = useState<NormTemplate>(NORMS_CATALOG[5]); // Default to concrete

  if (!isOpen) return null;

  const results = searchNorms(query);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4">
      <div className="bg-white rounded-lg shadow-2xl border border-slate-300 w-full max-w-4xl h-[80vh] flex flex-col text-xs text-slate-800 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <Search className="w-4 h-4 text-blue-400" />
            <h3 className="font-bold text-sm tracking-tight">TRA CỨU ĐỊNH MỨC XÂY DỰNG (THÔNG TƯ 12/2021/TT-BXD)</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search Input Bar */}
        <div className="p-3 bg-slate-100 border-b border-slate-200 flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Gõ mã hiệu (AF.12, BB.11) hoặc từ khóa bất kỳ: bê tông móng, xây gạch, trát tường, cốt thép (hỗ trợ không dấu)..."
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded bg-white focus:outline-hidden focus:ring-2 focus:ring-blue-500 font-medium"
            />
          </div>
          <span className="text-[11px] text-slate-500 shrink-0">
            Tìm thấy: <strong>{results.length}</strong> công tác
          </span>
        </div>

        {/* Split View: List (Left) + Norm Breakdown Preview (Right) */}
        <div className="flex-1 flex overflow-hidden">
          {/* Candidate List */}
          <div className="w-7/12 border-r border-slate-200 overflow-y-auto">
            <table className="w-full border-collapse table-auto select-text">
              <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 text-slate-700">
                <tr>
                  <th className="f1-header-cell w-24">Mã hiệu</th>
                  <th className="f1-header-cell text-left px-3">Tên công tác định mức</th>
                  <th className="f1-header-cell w-16">ĐVT</th>
                </tr>
              </thead>
              <tbody>
                {results.map((norm) => {
                  const isSelected = selectedPreviewNorm.code === norm.code;
                  return (
                    <tr
                      key={norm.code}
                      onClick={() => setSelectedPreviewNorm(norm)}
                      onDoubleClick={() => {
                        onSelectNorm(norm);
                        onClose();
                      }}
                      className={`cursor-pointer border-b border-slate-100 transition-colors ${
                        isSelected ? 'bg-blue-50 font-medium text-blue-900' : 'hover:bg-slate-50 text-slate-800'
                      }`}
                    >
                      <td className="f1-cell text-center font-mono font-semibold text-blue-700">
                        {norm.code}
                      </td>
                      <td className="f1-cell px-3">
                        <div>{norm.name}</div>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          VL: {formatVND(norm.defaultPriceMat)} · NC: {formatVND(norm.defaultPriceLab)} · Máy: {formatVND(norm.defaultPriceMac)}
                        </div>
                      </td>
                      <td className="f1-cell text-center text-slate-500">{norm.unit}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Norm Breakdown Preview */}
          <div className="w-5/12 bg-slate-50/60 p-4 overflow-y-auto flex flex-col justify-between">
            <div>
              <div className="bg-white p-3 rounded border border-slate-200 shadow-2xs mb-3">
                <span className="font-mono font-bold text-blue-700 text-xs block mb-0.5">
                  {selectedPreviewNorm.code} ({selectedPreviewNorm.unit})
                </span>
                <h4 className="font-bold text-slate-900 text-xs leading-snug">
                  {selectedPreviewNorm.name}
                </h4>
              </div>

              {/* Composition details */}
              <div className="space-y-3">
                {/* Materials */}
                <div>
                  <span className="font-bold text-blue-900 text-[11px] block mb-1">
                    1. Vật liệu định mức (trên 1 {selectedPreviewNorm.unit}):
                  </span>
                  {selectedPreviewNorm.materials.length === 0 ? (
                    <span className="text-slate-400 italic text-[11px]">Không hao phí vật liệu</span>
                  ) : (
                    <ul className="space-y-1 text-[11px]">
                      {selectedPreviewNorm.materials.map(m => (
                        <li key={m.code} className="flex justify-between bg-white px-2 py-1 rounded border border-slate-200">
                          <span className="truncate max-w-[180px]">{m.name}</span>
                          <span className="font-mono text-slate-600">{m.norm} {m.unit}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>

                {/* Labor */}
                <div>
                  <span className="font-bold text-amber-900 text-[11px] block mb-1">
                    2. Nhân công định mức:
                  </span>
                  {selectedPreviewNorm.labors.length === 0 ? (
                    <span className="text-slate-400 italic text-[11px]">Không hao phí nhân công</span>
                  ) : (
                    <ul className="space-y-1 text-[11px]">
                      {selectedPreviewNorm.labors.map(l => (
                        <li key={l.code} className="flex justify-between bg-white px-2 py-1 rounded border border-slate-200">
                          <span>{l.name} ({l.rank})</span>
                          <span className="font-mono text-slate-600">{l.norm} công</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>

                {/* Machine */}
                <div>
                  <span className="font-bold text-emerald-900 text-[11px] block mb-1">
                    3. Máy thi công định mức:
                  </span>
                  {selectedPreviewNorm.machines.length === 0 ? (
                    <span className="text-slate-400 italic text-[11px]">Không hao phí ca máy</span>
                  ) : (
                    <ul className="space-y-1 text-[11px]">
                      {selectedPreviewNorm.machines.map(mac => (
                        <li key={mac.code} className="flex justify-between bg-white px-2 py-1 rounded border border-slate-200">
                          <span className="truncate max-w-[180px]">{mac.name}</span>
                          <span className="font-mono text-slate-600">{mac.norm} ca</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            </div>

            <div className="pt-4 mt-4 border-t border-slate-200">
              <button
                onClick={() => {
                  onSelectNorm(selectedPreviewNorm);
                  onClose();
                }}
                className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>CHỌN CÔNG TÁC NÀY VÀO DỰ TOÁN</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import {
  FileSpreadsheet,
  Layers,
  BarChart3,
  Search,
  Plus,
  Download,
  Upload,
  Settings,
  Code,
  CheckCircle2,
  Calendar,
  Send,
  FileCheck2,
  RefreshCw,
  Coins,
  MapPin
} from 'lucide-react';
import { ProjectSettings } from '../types/estimate';
import { PROVINCES_DATA } from '../data/provincesData';

export type ActiveTab =
  | 'cong-trinh'
  | 'ptvt'
  | 'thvt'
  | 'dgct'
  | 'du-thau'
  | 'thkp'
  | 'tham-tra'
  | 'quyet-toan'
  | 'tien-do'
  | 'dau-thau'
  | 'python-api';

interface HeaderRibbonProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  settings: ProjectSettings;
  onChangeProvince: (provinceName: string) => void;
  onOpenSettings: () => void;
  onOpenNormLookup: () => void;
  onOpenMonthlyPrice: () => void;
  onAddWorkItem: () => void;
  onAddSubCalculation: () => void;
  onExportExcel: () => void;
  onImportExcel: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onOpenPythonModal: () => void;
  onResetSample: () => void;
}

export const HeaderRibbon: React.FC<HeaderRibbonProps> = ({
  activeTab,
  setActiveTab,
  settings,
  onChangeProvince,
  onOpenSettings,
  onOpenNormLookup,
  onOpenMonthlyPrice,
  onAddWorkItem,
  onAddSubCalculation,
  onExportExcel,
  onImportExcel,
  onOpenPythonModal,
  onResetSample
}) => {
  const currentProvince = PROVINCES_DATA.find(p => p.name === settings.locationProvince) || PROVINCES_DATA[0];

  const tabs: { id: ActiveTab; label: string; icon: React.ReactNode }[] = [
    { id: 'cong-trinh', label: '1. Bảng Công trình', icon: <FileSpreadsheet className="w-3.5 h-3.5" /> },
    { id: 'ptvt', label: '2. Phân tích vật tư', icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'thvt', label: '3. Giá tháng & THVT', icon: <Coins className="w-3.5 h-3.5" /> },
    { id: 'dgct', label: '4. Đơn giá chi tiết', icon: <FileCheck2 className="w-3.5 h-3.5" /> },
    { id: 'du-thau', label: '5. Bảng Dự thầu', icon: <BarChart3 className="w-3.5 h-3.5" /> },
    { id: 'thkp', label: '6. Tổng hợp THKP', icon: <FileSpreadsheet className="w-3.5 h-3.5" /> },
    { id: 'tham-tra', label: '7. Thẩm tra sai lệch', icon: <CheckCircle2 className="w-3.5 h-3.5 text-amber-500" /> },
    { id: 'quyet-toan', label: '8. Thanh Quyết toán (03a/03b)', icon: <Coins className="w-3.5 h-3.5" /> },
    { id: 'tien-do', label: '9. Tiến độ thi công', icon: <Calendar className="w-3.5 h-3.5" /> },
    { id: 'dau-thau', label: '10. Đấu thầu E-GP', icon: <Send className="w-3.5 h-3.5" /> },
    { id: 'python-api', label: '11. Xuất Python & API', icon: <Code className="w-3.5 h-3.5 text-blue-500" /> },
  ];

  return (
    <header className="bg-slate-900 text-slate-100 border-b border-slate-800 shadow-sm select-none">
      {/* Top Application Bar */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="flex items-center justify-center w-7 h-7 bg-red-600 rounded text-white font-black text-xs tracking-wider shadow-sm">
              F1
            </span>
            <span className="font-bold text-sm tracking-tight text-white whitespace-nowrap">
              DỰ TOÁN F1 PRO
            </span>
          </div>
          <span className="text-slate-600">|</span>

          {/* Quick 63 Province Selector */}
          <div className="flex items-center gap-1.5 bg-slate-800/90 border border-slate-700/80 rounded px-2 py-1">
            <MapPin className="w-3.5 h-3.5 text-red-400 shrink-0" />
            <span className="text-[11px] text-slate-400 font-medium shrink-0">Bộ Đơn giá (63 Tỉnh/Thành):</span>
            <select
              value={settings.locationProvince}
              onChange={(e) => onChangeProvince(e.target.value)}
              className="bg-transparent text-white font-semibold text-xs focus:outline-hidden cursor-pointer"
            >
              {PROVINCES_DATA.map(p => (
                <option key={p.id} value={p.name} className="bg-slate-900 text-slate-100">
                  {p.name} (Vùng {p.region})
                </option>
              ))}
            </select>
          </div>

          <span className="hidden lg:inline text-slate-600">·</span>
          <span className="hidden lg:inline text-xs text-slate-400 truncate max-w-[200px]" title={settings.projectName}>
            {settings.projectName}
          </span>
          <span className="hidden xl:inline text-emerald-400 font-mono text-[11px]">{settings.standardCircular.split('&')[0]}</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenSettings}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors whitespace-nowrap"
            title="Cấu hình công trình, thông tư áp dụng, loại công trình, thuế VAT"
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Cấu hình dự án</span>
          </button>

          <button
            onClick={onOpenPythonModal}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs text-blue-300 hover:text-white bg-blue-950/60 hover:bg-blue-900/80 border border-blue-800/50 rounded transition-colors whitespace-nowrap"
            title="Tải mã nguồn Python và kết nối REST API"
          >
            <Code className="w-3.5 h-3.5 text-blue-400" />
            <span>Xuất mã Python & API</span>
          </button>

          <button
            onClick={onResetSample}
            className="flex items-center gap-1 px-2 py-1 text-xs text-slate-400 hover:text-slate-200 bg-slate-800/60 hover:bg-slate-700/60 rounded transition-colors"
            title="Tải lại dữ liệu công trình mẫu"
          >
            <RefreshCw className="w-3 h-3" />
            <span className="hidden md:inline">Mẫu chuẩn</span>
          </button>
        </div>
      </div>

      {/* Ribbon Action Toolbar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-slate-800/50 text-xs overflow-x-auto gap-2 border-b border-slate-700/60">
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={onOpenNormLookup}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-medium shadow-sm transition-colors whitespace-nowrap"
          >
            <Search className="w-3.5 h-3.5" />
            <span>Tra định mức (F2)</span>
          </button>

          <button
            onClick={onAddWorkItem}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-100 rounded transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5 text-emerald-400" />
            <span>Thêm công tác</span>
          </button>

          <button
            onClick={onAddSubCalculation}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-100 rounded transition-colors whitespace-nowrap"
            title="Chèn dòng diễn giải dài x rộng x cao dưới công tác hiện tại"
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            <span>Chèn diễn giải KL</span>
          </button>

          <div className="w-[1px] h-5 bg-slate-700 mx-1" />

          <button
            onClick={onOpenMonthlyPrice}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-100 rounded transition-colors whitespace-nowrap"
            title={`Tự động áp giá thông báo vật liệu mới nhất từ Sở Xây dựng ${settings.locationProvince}`}
          >
            <Coins className="w-3.5 h-3.5 text-yellow-400" />
            <span>Lắp giá tháng Sở XD ({settings.locationProvince})</span>
          </button>

          <div className="w-[1px] h-5 bg-slate-700 mx-1" />

          <button
            onClick={onExportExcel}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded font-medium transition-colors whitespace-nowrap"
            title="Xuất trọn bộ 8 sheet dự toán ra file Excel .xlsx"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Xuất Excel (.xlsx)</span>
          </button>

          <label className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-100 rounded cursor-pointer transition-colors whitespace-nowrap">
            <Upload className="w-3.5 h-3.5 text-sky-400" />
            <span>Nhập Excel</span>
            <input
              type="file"
              accept=".xlsx,.xls,.csv"
              onChange={onImportExcel}
              className="hidden"
            />
          </label>
        </div>

        <div className="flex items-center gap-3 shrink-0 text-[11px] text-slate-400">
          <span>Tỉnh: <strong className="text-white">{currentProvince.name}</strong></span>
          <span>Vùng: <strong className="text-amber-400 font-mono">{currentProvince.region}</strong></span>
          <span>Hệ số NC: <strong className="text-emerald-400 font-mono">{currentProvince.laborCoefficient}</strong></span>
          <span>Máy TC: <strong className="text-emerald-400 font-mono">{currentProvince.machineCoefficient}</strong></span>
          <span>VAT: <strong className="text-amber-400 font-mono">{(settings.vatRate * 100).toFixed(0)}%</strong></span>
        </div>
      </div>

      {/* Main Module Tabs (F1 authentic bottom sheet style) */}
      <div className="flex items-center gap-0.5 px-2 bg-slate-950 overflow-x-auto text-xs border-t border-slate-800">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-2 font-medium transition-colors border-b-2 whitespace-nowrap ${
                isActive
                  ? 'bg-slate-800 text-white border-red-500 shadow-inner'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900 border-transparent'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};

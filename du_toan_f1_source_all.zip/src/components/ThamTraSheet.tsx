import React, { useState } from 'react';
import { AuditDiffItem, ProjectSettings } from '../types/estimate';
import { formatQuantity, formatVND } from '../utils/calculator';
import { CheckCircle2, AlertTriangle, XCircle, Search, Filter, ShieldCheck, ArrowDownRight } from 'lucide-react';

interface ThamTraSheetProps {
  auditDiffs: AuditDiffItem[];
  settings: ProjectSettings;
  onUpdateAuditDiff: (index: number, patch: Partial<AuditDiffItem>) => void;
  onApplyAllAuditChanges: () => void;
}

export const ThamTraSheet: React.FC<ThamTraSheetProps> = ({
  auditDiffs,
  settings,
  onUpdateAuditDiff,
  onApplyAllAuditChanges,
}) => {
  const [filterStatus, setFilterStatus] = useState<'all' | 'error' | 'warning' | 'matched'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  let totalOriginal = 0;
  let totalAudit = 0;
  let totalDiff = 0;

  auditDiffs.forEach(item => {
    totalOriginal += item.originalTotal;
    totalAudit += item.auditTotal;
    totalDiff += item.diffTotal;
  });

  const percentReduced = totalOriginal > 0 ? (totalDiff / totalOriginal) * 100 : 0;

  const filtered = auditDiffs.filter(item => {
    const matchesFilter = filterStatus === 'all' || item.status === filterStatus;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.code.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="flex-1 flex flex-col h-full bg-white overflow-hidden text-xs">
      {/* Top Audit KPI Banner */}
      <div className="grid grid-cols-4 gap-3 p-3 bg-slate-100 border-b border-slate-200">
        <div className="bg-white p-2.5 rounded border border-slate-200 shadow-xs">
          <span className="text-[11px] text-slate-500 block">Giá trị hồ sơ Thiết kế / Tư vấn:</span>
          <span className="text-sm font-bold text-slate-800 font-mono">{formatVND(totalOriginal)} VNĐ</span>
        </div>
        <div className="bg-white p-2.5 rounded border border-slate-200 shadow-xs">
          <span className="text-[11px] text-slate-500 block">Giá trị sau Thẩm tra:</span>
          <span className="text-sm font-bold text-blue-700 font-mono">{formatVND(totalAudit)} VNĐ</span>
        </div>
        <div className="bg-white p-2.5 rounded border border-slate-200 shadow-xs">
          <span className="text-[11px] text-slate-500 block">Giá trị cắt giảm / chênh lệch:</span>
          <div className="flex items-center gap-1">
            <ArrowDownRight className="w-4 h-4 text-emerald-600" />
            <span className="text-sm font-bold text-emerald-700 font-mono">
              {formatVND(totalDiff)} VNĐ ({percentReduced.toFixed(2)}%)
            </span>
          </div>
        </div>
        <div className="bg-white p-2.5 rounded border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] text-slate-500 block">Trạng thái thẩm tra:</span>
            <span className="font-semibold text-emerald-700 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Đã đối chiếu định mức TT12</span>
            </span>
          </div>
          <button
            onClick={onApplyAllAuditChanges}
            className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded font-medium text-[11px] shadow-xs transition-colors"
            title="Đồng bộ kết quả thẩm tra vào Bảng Công trình chính"
          >
            Áp dụng kết quả
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-slate-50 border-b border-slate-200">
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm công tác thẩm tra..."
              className="pl-8 pr-3 py-1 text-xs border border-slate-300 rounded bg-white w-56 focus:outline-hidden focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center gap-1 p-0.5 bg-slate-200/80 rounded">
            <button
              onClick={() => setFilterStatus('all')}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                filterStatus === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Tất cả ({auditDiffs.length})
            </button>
            <button
              onClick={() => setFilterStatus('error')}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                filterStatus === 'error' ? 'bg-white text-red-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Sai lệch KL / Giá ({auditDiffs.filter(i => i.status === 'error').length})
            </button>
            <button
              onClick={() => setFilterStatus('warning')}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                filterStatus === 'warning' ? 'bg-white text-amber-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Cảnh báo định mức ({auditDiffs.filter(i => i.status === 'warning').length})
            </button>
            <button
              onClick={() => setFilterStatus('matched')}
              className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                filterStatus === 'matched' ? 'bg-white text-emerald-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Trùng khớp ({auditDiffs.filter(i => i.status === 'matched').length})
            </button>
          </div>
        </div>

        <span className="text-[11px] text-slate-500">
          Chức năng đối chiếu tự động phát hiện đo bóc thừa hoặc sai đơn giá
        </span>
      </div>

      {/* Audit Comparison Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full border-collapse border border-slate-300 table-auto select-text">
          <thead className="sticky top-0 z-10 bg-slate-100 shadow-xs">
            <tr className="border-b border-slate-300">
              <th rowSpan={2} className="f1-header-cell w-10">STT</th>
              <th rowSpan={2} className="f1-header-cell w-20">Trạng thái</th>
              <th rowSpan={2} className="f1-header-cell w-24">Mã hiệu</th>
              <th rowSpan={2} className="f1-header-cell min-w-[200px] text-left px-3">Tên công tác đối chiếu</th>
              <th rowSpan={2} className="f1-header-cell w-14">ĐVT</th>
              <th colSpan={3} className="f1-header-cell">Khối lượng</th>
              <th colSpan={3} className="f1-header-cell">Thành tiền (VNĐ)</th>
              <th rowSpan={2} className="f1-header-cell min-w-[240px] text-left px-3">Lý do & giải trình thẩm tra</th>
            </tr>
            <tr className="border-b border-slate-300 bg-slate-50">
              <th className="f1-header-cell w-20">Gốc (TK)</th>
              <th className="f1-header-cell w-20 bg-blue-50">Thẩm tra</th>
              <th className="f1-header-cell w-20">Chênh lệch</th>
              <th className="f1-header-cell w-28">Gốc (TK)</th>
              <th className="f1-header-cell w-28 bg-blue-50">Thẩm tra</th>
              <th className="f1-header-cell w-28 font-bold text-red-900 bg-red-50">Chênh lệch</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((item, idx) => {
              const isError = item.status === 'error';
              const isWarning = item.status === 'warning';
              const isMatched = item.status === 'matched';

              return (
                <tr
                  key={item.code + idx}
                  className={`hover:bg-slate-50 transition-colors ${
                    isError ? 'bg-red-50/20' : isWarning ? 'bg-amber-50/20' : ''
                  }`}
                >
                  <td className="f1-cell text-center text-slate-500 font-mono">{idx + 1}</td>
                  <td className="f1-cell text-center">
                    {isError && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-red-600">
                        <XCircle className="w-3.5 h-3.5" /> Sai lệch
                      </span>
                    )}
                    {isWarning && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-600">
                        <AlertTriangle className="w-3.5 h-3.5" /> Lưu ý
                      </span>
                    )}
                    {isMatched && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Khớp
                      </span>
                    )}
                  </td>
                  <td className="f1-cell text-center font-mono font-medium text-blue-700">{item.code}</td>
                  <td className="f1-cell px-3 text-slate-800 font-medium">{item.name}</td>
                  <td className="f1-cell text-center text-slate-600">{item.unit}</td>
                  <td className="f1-cell text-right tabular-nums text-slate-700 font-mono">{formatQuantity(item.originalQty)}</td>
                  <td className="f1-cell text-right tabular-nums text-blue-800 font-semibold font-mono bg-blue-50/30">
                    <input
                      type="number"
                      step="any"
                      value={item.auditQty}
                      onChange={(e) => {
                        const newAuditQty = parseFloat(e.target.value) || 0;
                        const diffQty = newAuditQty - item.originalQty;
                        const unitP = item.originalTotal / (item.originalQty || 1);
                        const newAuditTotal = newAuditQty * unitP;
                        onUpdateAuditDiff(idx, {
                          auditQty: newAuditQty,
                          diffQty,
                          auditTotal: newAuditTotal,
                          diffTotal: newAuditTotal - item.originalTotal,
                          status: diffQty === 0 ? 'matched' : 'error'
                        });
                      }}
                      className="w-16 text-right bg-transparent focus:bg-white focus:outline-hidden px-1 rounded font-mono"
                    />
                  </td>
                  <td className={`f1-cell text-right tabular-nums font-mono font-medium ${item.diffQty !== 0 ? 'text-red-700' : 'text-slate-400'}`}>
                    {item.diffQty !== 0 ? (item.diffQty > 0 ? `+${formatQuantity(item.diffQty)}` : formatQuantity(item.diffQty)) : '0'}
                  </td>
                  <td className="f1-cell text-right tabular-nums text-slate-700">{formatVND(item.originalTotal)}</td>
                  <td className="f1-cell text-right tabular-nums font-semibold text-blue-900 bg-blue-50/30">{formatVND(item.auditTotal)}</td>
                  <td className={`f1-cell text-right tabular-nums font-bold font-mono ${item.diffTotal !== 0 ? 'text-red-700 bg-red-50/40' : 'text-slate-400'}`}>
                    {item.diffTotal !== 0 ? formatVND(item.diffTotal) : '0'}
                  </td>
                  <td className="f1-cell px-3 text-slate-600 italic">
                    <input
                      type="text"
                      value={item.reason}
                      onChange={(e) => onUpdateAuditDiff(idx, { reason: e.target.value })}
                      className="w-full bg-transparent focus:bg-white focus:outline-hidden px-1 py-0.5 rounded text-slate-700"
                    />
                  </td>
                </tr>
              );
            })}
          </tbody>
          <tfoot className="sticky bottom-0 z-10 bg-slate-900 text-white font-bold text-xs shadow-md">
            <tr className="border-t-2 border-slate-700">
              <td colSpan={7} className="f1-cell text-center py-2 text-slate-300">
                TỔNG CỘNG CHÊNH LỆCH SAU THẨM TRA
              </td>
              <td className="f1-cell text-right tabular-nums text-slate-300">{formatVND(totalOriginal)}</td>
              <td className="f1-cell text-right tabular-nums text-blue-400">{formatVND(totalAudit)}</td>
              <td className="f1-cell text-right tabular-nums text-emerald-400 font-bold bg-slate-800 text-sm">
                {formatVND(totalDiff)}
              </td>
              <td className="f1-cell px-3 text-emerald-400">
                Giảm trừ {percentReduced.toFixed(2)}% tổng giá trị dự toán
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
};

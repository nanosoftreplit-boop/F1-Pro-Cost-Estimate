import React, { useState } from 'react';
import { ProjectSettings, ProjectType } from '../types/estimate';
import { PROVINCES_DATA } from '../data/normsData';
import { Settings, Check, X } from 'lucide-react';

interface ProjectSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: ProjectSettings;
  onSaveSettings: (newSettings: ProjectSettings) => void;
}

export const ProjectSettingsModal: React.FC<ProjectSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
}) => {
  const [formData, setFormData] = useState<ProjectSettings>({ ...settings });

  if (!isOpen) return null;

  const handleProvinceChange = (provinceName: string) => {
    const prov = PROVINCES_DATA.find(p => p.name === provinceName);
    if (prov) {
      setFormData(prev => ({
        ...prev,
        locationProvince: prov.name,
        salaryRegion: prov.region
      }));
    } else {
      setFormData(prev => ({ ...prev, locationProvince: provinceName }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4">
      <div className="bg-white rounded-lg shadow-2xl border border-slate-300 w-full max-w-lg flex flex-col text-xs text-slate-800 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4 text-blue-400" />
            <h3 className="font-bold text-sm tracking-tight">CẤU HÌNH CÔNG TRÌNH & HỆ SỐ ĐỊNH MỨC</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-3.5">
          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Tên công trình:</label>
            <input
              type="text"
              required
              value={formData.projectName}
              onChange={(e) => setFormData({ ...formData, projectName: e.target.value })}
              className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-xs font-medium focus:outline-hidden focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Chủ đầu tư:</label>
              <input
                type="text"
                value={formData.investor}
                onChange={(e) => setFormData({ ...formData, investor: e.target.value })}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-xs focus:outline-hidden focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Đơn vị lập dự toán:</label>
              <input
                type="text"
                value={formData.contractor}
                onChange={(e) => setFormData({ ...formData, contractor: e.target.value })}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-xs focus:outline-hidden focus:ring-1 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Địa điểm (Tỉnh / Thành phố):</label>
              <select
                value={formData.locationProvince}
                onChange={(e) => handleProvinceChange(e.target.value)}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-xs font-semibold focus:outline-hidden focus:ring-1 focus:ring-blue-500"
              >
                {PROVINCES_DATA.map(p => (
                  <option key={p.id} value={p.name}>
                    {p.name} (Vùng {p.region})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Vùng lương nhân công:</label>
              <select
                value={formData.salaryRegion}
                onChange={(e) => setFormData({ ...formData, salaryRegion: e.target.value as any })}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-xs font-semibold focus:outline-hidden focus:ring-1 focus:ring-blue-500"
              >
                <option value="I">Vùng I (Hà Nội, TP.HCM, Hải Phòng...)</option>
                <option value="II">Vùng II (Đà Nẵng, Cần Thơ, Quảng Ninh...)</option>
                <option value="III">Vùng III (Nghệ An, Lâm Đồng...)</option>
                <option value="IV">Vùng IV (Các huyện miền núi, khó khăn)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Loại công trình xây dựng:</label>
              <select
                value={formData.projectType}
                onChange={(e) => setFormData({ ...formData, projectType: e.target.value as ProjectType })}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-xs font-semibold focus:outline-hidden focus:ring-1 focus:ring-blue-500"
              >
                <option value="civil">Công trình Dân dụng (Chi phí chung: 7.3%)</option>
                <option value="industrial">Công trình Công nghiệp (Chi phí chung: 6.2%)</option>
                <option value="transport">Công trình Giao thông (Chi phí chung: 5.5%)</option>
                <option value="infrastructure">Công trình Hạ tầng kỹ thuật (Chi phí chung: 5.0%)</option>
                <option value="agriculture">Công trình Nông nghiệp & PTNT (Chi phí chung: 5.8%)</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">Thuế suất thuế GTGT (VAT):</label>
              <select
                value={formData.vatRate}
                onChange={(e) => setFormData({ ...formData, vatRate: parseFloat(e.target.value) })}
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-xs font-bold text-amber-700 focus:outline-hidden focus:ring-1 focus:ring-blue-500"
              >
                <option value={0.10}>Thuế suất 10% (Chuẩn luật thuế GTGT)</option>
                <option value={0.08}>Thuế suất 8% (Chính sách giảm thuế hỗ trợ)</option>
              </select>
            </div>
          </div>

          {/* Tự động hóa chi phí gián tiếp TT11 */}
          <div className="p-2.5 bg-blue-50/70 rounded border border-blue-200 space-y-2">
            <div className="font-semibold text-blue-900 text-xs flex items-center justify-between">
              <span>Tự động hóa Chi phí gián tiếp (Thông tư 11/2021/TT-BXD):</span>
              <span className="text-[10px] text-blue-700 font-mono">Bảng 3.1 &amp; 3.2</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div>
                <label className="block text-[10px] text-slate-600 mb-0.5">Phương pháp tính:</label>
                <select
                  value={formData.indirectCostConfig?.method || 'by_scale'}
                  onChange={(e) => setFormData({
                    ...formData,
                    indirectCostConfig: {
                      ...(formData.indirectCostConfig || { enabledAuto: true, isLineProject: false, method: 'by_scale' }),
                      method: e.target.value as any
                    }
                  })}
                  className="w-full px-2 py-1 border border-slate-300 rounded bg-white text-[11px] font-medium"
                >
                  <option value="by_scale">Nội suy theo quy mô T</option>
                  <option value="by_category">Phân bổ theo từng hạng mục</option>
                </select>
              </div>
              <div className="flex items-center pt-3.5">
                <label className="flex items-center gap-1.5 cursor-pointer text-slate-700 text-[11px]">
                  <input
                    type="checkbox"
                    checked={Boolean(formData.indirectCostConfig?.isLineProject)}
                    onChange={(e) => setFormData({
                      ...formData,
                      indirectCostConfig: {
                        ...(formData.indirectCostConfig || { enabledAuto: true, method: 'by_scale', isLineProject: false }),
                        isLineProject: e.target.checked
                      }
                    })}
                    className="rounded text-blue-600"
                  />
                  <span>Công trình theo tuyến (Nhà tạm 2.2%)</span>
                </label>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-700 mb-1">Hệ thống Thông tư, Nghị định áp dụng:</label>
            <input
              type="text"
              value={formData.standardCircular}
              onChange={(e) => setFormData({ ...formData, standardCircular: e.target.value })}
              className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-slate-50 text-xs text-slate-600 focus:outline-hidden"
            />
          </div>

          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded font-medium transition-colors"
            >
              Hủy bỏ
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-bold transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Check className="w-3.5 h-3.5" />
              <span>LƯU CẤU HÌNH</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

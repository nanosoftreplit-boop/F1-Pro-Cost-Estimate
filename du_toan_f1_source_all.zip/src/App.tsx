/**
 * Dự toán F1 Pro - Phần mềm Lập dự toán, Dự thầu, Thẩm tra & Quyết toán công trình
 * Tuân thủ Thông tư 12/2021/TT-BXD, TT 11/2021/TT-BXD, TT 14/2023/TT-BXD, NĐ 99/2021/NĐ-CP
 */

import React, { useState, useEffect } from 'react';
import {
  WorkItem,
  Category,
  ProjectSettings,
  AuditDiffItem,
  SettlementItem,
  GanttTask,
  BiddingForm,
  NormTemplate,
  SubCalculation,
} from './types/estimate';
import {
  DEFAULT_PROJECT_SETTINGS,
  DEFAULT_CATEGORIES,
  INITIAL_WORK_ITEMS,
  SAMPLE_AUDIT_DIFFS,
  SAMPLE_SETTLEMENT_ITEMS,
  SAMPLE_GANTT_TASKS,
  SAMPLE_BIDDING_FORM,
} from './data/sampleProjects';
import { evaluateMathExpression } from './utils/calculator';
import { exportProjectToExcel, parseExcelFile } from './utils/excelExport';
import { PROVINCES_DATA } from './data/provincesData';

import { HeaderRibbon, ActiveTab } from './components/HeaderRibbon';
import { FormulaBar } from './components/FormulaBar';
import { CongTrinhSheet } from './components/CongTrinhSheet';
import { PhanTichVatTuSheet } from './components/PhanTichVatTuSheet';
import { TongHopVatTuSheet } from './components/TongHopVatTuSheet';
import { DonGiaChiTietSheet } from './components/DonGiaChiTietSheet';
import { DuThauSheet } from './components/DuThauSheet';
import { THKPSheet } from './components/THKPSheet';
import { ThamTraSheet } from './components/ThamTraSheet';
import { ThanhQuyetToanSheet } from './components/ThanhQuyetToanSheet';
import { TienDoGanttSheet } from './components/TienDoGanttSheet';
import { DauThauOnlineSheet } from './components/DauThauOnlineSheet';
import { PythonExportModal } from './components/PythonExportModal';
import { NormLookupModal } from './components/NormLookupModal';
import { PriceMonthlyModal } from './components/PriceMonthlyModal';
import { ProjectSettingsModal } from './components/ProjectSettingsModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('cong-trinh');
  const [items, setItems] = useState<WorkItem[]>(INITIAL_WORK_ITEMS);
  const [categories, setCategories] = useState<Category[]>(DEFAULT_CATEGORIES);
  const [settings, setSettings] = useState<ProjectSettings>(DEFAULT_PROJECT_SETTINGS);
  const [auditDiffs, setAuditDiffs] = useState<AuditDiffItem[]>(SAMPLE_AUDIT_DIFFS);
  const [settlements, setSettlements] = useState<SettlementItem[]>(SAMPLE_SETTLEMENT_ITEMS);
  const [tasks, setTasks] = useState<GanttTask[]>(SAMPLE_GANTT_TASKS);
  const [biddingForm, setBiddingForm] = useState<BiddingForm>(SAMPLE_BIDDING_FORM);

  // Selection
  const [selectedItemId, setSelectedItemId] = useState<string | null>(INITIAL_WORK_ITEMS[1]?.id || null);
  const [selectedSubCalcId, setSelectedSubCalcId] = useState<string | null>(null);

  // Modals
  const [isNormLookupOpen, setIsNormLookupOpen] = useState(false);
  const [targetReplaceItemId, setTargetReplaceItemId] = useState<string | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isMonthlyPriceOpen, setIsMonthlyPriceOpen] = useState(false);
  const [isPythonModalOpen, setIsPythonModalOpen] = useState(false);

  // Phím tắt F2 để mở tra cứu định mức nhanh
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F2') {
        e.preventDefault();
        setIsNormLookupOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const selectedItem = items.find(i => i.id === selectedItemId);
  const selectedSubCalc = selectedItem?.subCalculations?.find(s => s.id === selectedSubCalcId);

  // Chọn công tác hoặc dòng diễn giải
  const handleSelectItem = (item: WorkItem, subCalc?: SubCalculation) => {
    setSelectedItemId(item.id);
    setSelectedSubCalcId(subCalc ? subCalc.id : null);
  };

  // Cập nhật biểu thức tính toán từ FormulaBar
  const handleUpdateExpression = (expr: string) => {
    if (!selectedItemId) return;
    const qty = evaluateMathExpression(expr);

    if (selectedSubCalcId) {
      // Đang chọn dòng con
      setItems(prev => prev.map(item => {
        if (item.id !== selectedItemId) return item;
        const updatedSubs = (item.subCalculations || []).map(s => {
          if (s.id !== selectedSubCalcId) return s;
          return { ...s, expression: expr, quantity: qty };
        });
        const totalQty = updatedSubs.reduce((sum, s) => sum + s.quantity, 0);
        return { ...item, subCalculations: updatedSubs, quantity: totalQty };
      }));
    } else {
      // Đang chọn dòng công tác cha
      setItems(prev => prev.map(item => {
        if (item.id !== selectedItemId) return item;
        return { ...item, quantity: qty };
      }));
    }
  };

  // Cập nhật công tác
  const handleUpdateWorkItem = (itemId: string, patch: Partial<WorkItem>) => {
    setItems(prev => prev.map(item => item.id === itemId ? { ...item, ...patch } : item));
  };

  // Xóa công tác
  const handleDeleteWorkItem = (itemId: string) => {
    setItems(prev => prev.filter(item => item.id !== itemId));
    if (selectedItemId === itemId) {
      setSelectedItemId(null);
      setSelectedSubCalcId(null);
    }
  };

  // Thêm công tác mới
  const handleAddWorkItem = () => {
    setTargetReplaceItemId(null);
    setIsNormLookupOpen(true);
  };

  // Chọn định mức từ modal
  const handleSelectNormFromModal = (norm: NormTemplate) => {
    if (targetReplaceItemId) {
      // Thay thế công tác đã có
      setItems(prev => prev.map(item => {
        if (item.id !== targetReplaceItemId) return item;
        return {
          ...item,
          code: norm.code,
          name: norm.name,
          unit: norm.unit,
          unitPriceMaterial: norm.defaultPriceMat,
          unitPriceLabor: norm.defaultPriceLab,
          unitPriceMachine: norm.defaultPriceMac,
          materials: norm.materials,
          labors: norm.labors,
          machines: norm.machines,
        };
      }));
      setTargetReplaceItemId(null);
    } else {
      // Thêm mới
      const newStt = items.length + 1;
      const newItem: WorkItem = {
        id: `w-${Date.now()}`,
        stt: newStt,
        type: 'work',
        categoryId: categories[0]?.id || 'cat-1',
        code: norm.code,
        name: norm.name,
        unit: norm.unit,
        quantity: 1.0,
        subCalculations: [
          { id: `sub-${Date.now()}`, name: 'Khối lượng thiết kế', expression: '1.0', quantity: 1.0 }
        ],
        unitPriceMaterial: norm.defaultPriceMat,
        unitPriceLabor: norm.defaultPriceLab,
        unitPriceMachine: norm.defaultPriceMac,
        materials: norm.materials,
        labors: norm.labors,
        machines: norm.machines,
      };
      setItems(prev => [...prev, newItem]);
      setSelectedItemId(newItem.id);
      setSelectedSubCalcId(null);
    }
  };

  // Thêm dòng diễn giải con cho công tác
  const handleAddSubCalculation = (targetItemId?: string) => {
    const idToUse = targetItemId || selectedItemId;
    if (!idToUse) return;

    setItems(prev => prev.map(item => {
      if (item.id !== idToUse) return item;
      const newSub: SubCalculation = {
        id: `sub-${Date.now()}`,
        name: `Cấu kiện chi tiết ${(item.subCalculations?.length || 0) + 1}`,
        expression: '1 * 1.5 * 2.0',
        quantity: 3.0,
      };
      const updatedSubs = [...(item.subCalculations || []), newSub];
      const newQty = updatedSubs.reduce((sum, s) => sum + s.quantity, 0);
      return { ...item, subCalculations: updatedSubs, quantity: newQty };
    }));
  };

  // Cập nhật dòng diễn giải con
  const handleUpdateSubCalculation = (itemId: string, subId: string, patch: Partial<SubCalculation>) => {
    setItems(prev => prev.map(item => {
      if (item.id !== itemId) return item;
      const updatedSubs = (item.subCalculations || []).map(s => s.id === subId ? { ...s, ...patch } : s);
      const newQty = updatedSubs.reduce((sum, s) => sum + s.quantity, 0);
      return { ...item, subCalculations: updatedSubs, quantity: newQty };
    }));
  };

  // Xóa dòng diễn giải con
  const handleDeleteSubCalculation = (itemId: string, subId: string) => {
    setItems(prev => prev.map(item => {
      if (item.id !== itemId) return item;
      const updatedSubs = (item.subCalculations || []).filter(s => s.id !== subId);
      const newQty = updatedSubs.length > 0 ? updatedSubs.reduce((sum, s) => sum + s.quantity, 0) : item.quantity;
      return { ...item, subCalculations: updatedSubs, quantity: newQty };
    }));
    if (selectedSubCalcId === subId) {
      setSelectedSubCalcId(null);
    }
  };

  // Cập nhật giá tháng trên toàn dự án
  const handleUpdateMonthlyPrice = (matCode: string, newMonthlyPrice: number) => {
    setItems(prev => prev.map(item => {
      const updatedMaterials = (item.materials || []).map(m => {
        if (m.code === matCode) {
          return { ...m, monthlyPrice: newMonthlyPrice };
        }
        return m;
      });
      return { ...item, materials: updatedMaterials };
    }));
  };

  // Áp dụng hàng loạt giá thông báo tháng từ Sở Xây dựng
  const handleApplyMonthlyPricesBatch = (pricesMap: Record<string, number>) => {
    setItems(prev => prev.map(item => {
      const updatedMaterials = (item.materials || []).map(m => {
        if (pricesMap[m.code] !== undefined) {
          return { ...m, monthlyPrice: pricesMap[m.code] };
        }
        return m;
      });
      return { ...item, materials: updatedMaterials };
    }));
  };

  // Xuất file Excel
  const handleExportExcel = () => {
    exportProjectToExcel(items, categories, settings, settlements, tasks);
  };

  // Nhập file Excel
  const handleImportExcel = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const res = await parseExcelFile(file);
      if (res.items && res.items.length > 0) {
        const importedWorkItems: WorkItem[] = res.items.map((raw, idx) => ({
          id: `imp-${Date.now()}-${idx}`,
          stt: idx + 1,
          type: 'work',
          categoryId: categories[0]?.id || 'cat-1',
          code: raw.code || 'AF.TEMP',
          name: raw.name || `Công tác nhập khẩu ${idx + 1}`,
          unit: raw.unit || 'm3',
          quantity: raw.quantity || 1,
          subCalculations: [],
          unitPriceMaterial: raw.unitPriceMaterial || 0,
          unitPriceLabor: raw.unitPriceLabor || 0,
          unitPriceMachine: raw.unitPriceMachine || 0,
          materials: [],
          labors: [],
          machines: [],
        }));
        setItems(importedWorkItems);
        setActiveTab('cong-trinh');
      }
    } catch (err) {
      alert('Không thể đọc file Excel. Vui lòng kiểm tra lại định dạng file!');
    }
  };

  // Khôi phục dữ liệu mẫu
  const handleResetSample = () => {
    if (window.confirm('Khôi phục lại toàn bộ dữ liệu dự án mẫu chuẩn Dự toán F1?')) {
      setItems(INITIAL_WORK_ITEMS);
      setCategories(DEFAULT_CATEGORIES);
      setSettings(DEFAULT_PROJECT_SETTINGS);
      setAuditDiffs(SAMPLE_AUDIT_DIFFS);
      setSettlements(SAMPLE_SETTLEMENT_ITEMS);
      setTasks(SAMPLE_GANTT_TASKS);
      setBiddingForm(SAMPLE_BIDDING_FORM);
      setSelectedItemId(INITIAL_WORK_ITEMS[1]?.id || null);
      setSelectedSubCalcId(null);
    }
  };

  // Áp dụng kết quả thẩm tra
  const handleApplyAllAuditChanges = () => {
    setItems(prev => prev.map(item => {
      const diff = auditDiffs.find(d => d.code === item.code);
      if (diff) {
        return {
          ...item,
          quantity: diff.auditQty,
        };
      }
      return item;
    }));
    setActiveTab('cong-trinh');
  };

  // Thay đổi tỉnh thành (trong danh mục 63 tỉnh thành)
  const handleChangeProvince = (provinceName: string) => {
    const prov = PROVINCES_DATA.find(p => p.name === provinceName);
    if (prov) {
      setSettings(prev => ({
        ...prev,
        locationProvince: prov.name,
        salaryRegion: prov.region
      }));
    }
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-slate-100">
      {/* 1. Authentic F1 Header Ribbon */}
      <HeaderRibbon
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        settings={settings}
        onChangeProvince={handleChangeProvince}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenNormLookup={() => {
          setTargetReplaceItemId(null);
          setIsNormLookupOpen(true);
        }}
        onOpenMonthlyPrice={() => setIsMonthlyPriceOpen(true)}
        onAddWorkItem={handleAddWorkItem}
        onAddSubCalculation={() => handleAddSubCalculation()}
        onExportExcel={handleExportExcel}
        onImportExcel={handleImportExcel}
        onOpenPythonModal={() => setIsPythonModalOpen(true)}
        onResetSample={handleResetSample}
      />

      {/* 2. Formula Bar (Active when in Công trình sheet) */}
      {activeTab === 'cong-trinh' && (
        <FormulaBar
          selectedItem={selectedItem}
          selectedSubCalc={selectedSubCalc}
          onUpdateExpression={handleUpdateExpression}
        />
      )}

      {/* 3. Main Workspace Sub-System Content */}
      <main className="flex-1 overflow-hidden relative">
        {activeTab === 'cong-trinh' && (
          <CongTrinhSheet
            items={items}
            categories={categories}
            selectedItemId={selectedItemId}
            selectedSubCalcId={selectedSubCalcId}
            onSelectItem={handleSelectItem}
            onUpdateWorkItem={handleUpdateWorkItem}
            onDeleteWorkItem={handleDeleteWorkItem}
            onAddSubCalculation={handleAddSubCalculation}
            onUpdateSubCalculation={handleUpdateSubCalculation}
            onDeleteSubCalculation={handleDeleteSubCalculation}
            onOpenNormLookupForWorkItem={(itemId) => {
              setTargetReplaceItemId(itemId);
              setIsNormLookupOpen(true);
            }}
            onAddCategory={() => {
              const newCat: Category = {
                id: `cat-${Date.now()}`,
                name: `Hạng mục ${categories.length + 1}: Hạng mục mới bổ sung`,
              };
              setCategories(prev => [...prev, newCat]);
            }}
          />
        )}

        {activeTab === 'ptvt' && (
          <PhanTichVatTuSheet
            items={items}
            onUpdateWorkItem={handleUpdateWorkItem}
          />
        )}

        {activeTab === 'thvt' && (
          <TongHopVatTuSheet
            items={items}
            settings={settings}
            onUpdateMonthlyPrice={handleUpdateMonthlyPrice}
            onOpenMonthlyPriceModal={() => setIsMonthlyPriceOpen(true)}
          />
        )}

        {activeTab === 'dgct' && (
          <DonGiaChiTietSheet
            items={items}
            settings={settings}
          />
        )}

        {activeTab === 'du-thau' && (
          <DuThauSheet
            items={items}
            settings={settings}
          />
        )}

        {activeTab === 'thkp' && (
          <THKPSheet
            items={items}
            categories={categories}
            settings={settings}
            onUpdateSettings={setSettings}
            onUpdateCategories={setCategories}
            onExportExcel={handleExportExcel}
          />
        )}

        {activeTab === 'tham-tra' && (
          <ThamTraSheet
            auditDiffs={auditDiffs}
            settings={settings}
            onUpdateAuditDiff={(idx, patch) => {
              setAuditDiffs(prev => prev.map((item, i) => i === idx ? { ...item, ...patch } : item));
            }}
            onApplyAllAuditChanges={handleApplyAllAuditChanges}
          />
        )}

        {activeTab === 'quyet-toan' && (
          <ThanhQuyetToanSheet
            settlements={settlements}
            settings={settings}
            onUpdateSettlement={(id, patch) => {
              setSettlements(prev => prev.map(s => s.id === id ? { ...s, ...patch } : s));
            }}
            onAddSettlementItem={(isAdd) => {
              const newS: SettlementItem = {
                id: `s-${Date.now()}`,
                code: isAdd ? 'PS.001' : 'HD.NEW',
                name: isAdd ? 'Công việc phát sinh mới theo biên bản hiện trường' : 'Công việc trong hợp đồng',
                unit: 'm3',
                contractQty: isAdd ? 0 : 10,
                contractPrice: 1250000,
                prevAccumulatedQty: 0,
                thisPeriodQty: 5,
                totalAccumulatedQty: 5,
                isAdditional: isAdd,
              };
              setSettlements(prev => [...prev, newS]);
            }}
            onDeleteSettlementItem={(id) => {
              setSettlements(prev => prev.filter(s => s.id !== id));
            }}
          />
        )}

        {activeTab === 'tien-do' && (
          <TienDoGanttSheet
            tasks={tasks}
            settings={settings}
            onUpdateTask={(id, patch) => {
              setTasks(prev => prev.map(t => t.id === id ? { ...t, ...patch } : t));
            }}
            onAddTask={() => {
              const newTask: GanttTask = {
                id: `g-${Date.now()}`,
                name: `Công tác thi công ${tasks.length + 1}`,
                startDate: '2026-05-01',
                endDate: '2026-05-15',
                durationDays: 15,
                progressPercent: 0,
                workersRequired: 16,
              };
              setTasks(prev => [...prev, newTask]);
            }}
            onDeleteTask={(id) => {
              setTasks(prev => prev.filter(t => t.id !== id));
            }}
          />
        )}

        {activeTab === 'dau-thau' && (
          <DauThauOnlineSheet
            biddingForm={biddingForm}
            items={items}
            settings={settings}
            onUpdateBiddingForm={(patch) => setBiddingForm(prev => ({ ...prev, ...patch }))}
          />
        )}

        {activeTab === 'python-api' && (
          <div className="h-full flex items-center justify-center p-6 bg-slate-900">
            <div className="max-w-xl text-center space-y-4">
              <span className="p-3 bg-blue-600/20 text-blue-400 rounded-full inline-block border border-blue-500/30">
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                </svg>
              </span>
              <h2 className="text-xl font-bold text-white">Xuất mã nguồn Python & Tích hợp REST API</h2>
              <p className="text-xs text-slate-400 leading-relaxed">
                Tải về toàn bộ mã nguồn Python độc lập bao gồm engine tính toán, thư viện định mức Thông tư 12, máy chủ FastAPI và tài liệu API để đồng bộ hóa hai chiều với AutoCAD, Revit và hệ thống kế toán.
              </p>
              <button
                onClick={() => setIsPythonModalOpen(true)}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-bold text-xs shadow-md transition-colors"
              >
                Mở trung tâm Xuất Python & REST API
              </button>
            </div>
          </div>
        )}
      </main>

      {/* 4. Global Modals */}
      <NormLookupModal
        isOpen={isNormLookupOpen}
        onClose={() => setIsNormLookupOpen(false)}
        onSelectNorm={handleSelectNormFromModal}
      />

      <PriceMonthlyModal
        isOpen={isMonthlyPriceOpen}
        onClose={() => setIsMonthlyPriceOpen(false)}
        settings={settings}
        onApplyMonthlyPrices={handleApplyMonthlyPricesBatch}
      />

      <ProjectSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={(newSettings) => setSettings(newSettings)}
      />

      <PythonExportModal
        isOpen={isPythonModalOpen}
        onClose={() => setIsPythonModalOpen(false)}
        items={items}
        categories={categories}
        settings={settings}
        settlements={settlements}
        tasks={tasks}
        biddingForm={biddingForm}
      />
    </div>
  );
}
